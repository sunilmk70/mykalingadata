package com.mindtree.bookstore.service.bookServiceImpl;

import java.util.List;

import com.mindtree.bookstore.DAO.BookDAO;
import com.mindtree.bookstore.DAO.bookDAOImpl.BookDAOImpl;
import com.mindtree.bookstore.service.BookService;
import com.mindtree.bookstore.entities.Book;
import com.mindtree.bookstore.entities.Purchase;

public class BookServiceImpl implements BookService
{
	BookDAO bookDAO=new BookDAOImpl();
	public List<Book> getBookDetails() 
	{
		return bookDAO.getBookDetails();
	}
	public String getMessage()
	{
		return bookDAO.getMessage();
	}
	@Override
	public void addPurchase(Purchase p) 
	{
		// TODO Auto-generated method stub
		bookDAO.addPurchase(p);
	}
	public List<Book> getBookByCategory(String category)
	{
		return bookDAO.getBookByCategory(category);
	}

}
