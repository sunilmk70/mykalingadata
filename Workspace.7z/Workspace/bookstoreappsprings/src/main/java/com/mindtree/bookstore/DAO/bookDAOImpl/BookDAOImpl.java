package com.mindtree.bookstore.DAO.bookDAOImpl;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
//import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.mindtree.bookstore.DAO.BookDAO;
import com.mindtree.bookstore.entities.Book;
import com.mindtree.bookstore.entities.Purchase;
public class BookDAOImpl implements BookDAO
{
	protected SessionFactory sessionFactory;
	public void setup()
	{
		final StandardServiceRegistry registry=new StandardServiceRegistryBuilder().configure().build();
		try {
			sessionFactory= new MetadataSources(registry).buildMetadata().buildSessionFactory();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}
	public List<Book> getBookDetails() 
	{
		List<Book>list=null;
		
		try {
			setup();
			String s="From Book";
			Session session=sessionFactory.openSession();
			session.beginTransaction();
			Query query=session.createQuery(s) ;
			list=query.list();
			session.getTransaction().commit();
			session.close();
			return list;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//return null;
		}
		return list; 
	}
	public String getMessage()
	{
		return "My String";
	}
	
	public void addPurchase(Purchase p)
	{
		
		try {
			setup();
			Session session=sessionFactory.openSession();
			session.beginTransaction();
			session.saveOrUpdate(p);
			//session.persist(p);
			session.getTransaction().commit();
			session.close();
	
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<Book> getBookByCategory(String category) 
	{

		List<Book>list=getBookDetails();
		List<Book>list1=new ArrayList<Book>();
		Iterator it=list.iterator();
		while(it.hasNext())
		{
		  Book b=(Book)it.next();
		  if(b.getCategoryName().equalsIgnoreCase(category))
		  {
			  list1.add(b);
		  }
		}
		return list1;
	}
	
}
	

