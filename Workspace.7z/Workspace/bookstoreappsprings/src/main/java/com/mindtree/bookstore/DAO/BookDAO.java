package com.mindtree.bookstore.DAO;

import java.util.List;

import com.mindtree.bookstore.entities.Book;
import com.mindtree.bookstore.entities.Purchase;

public interface BookDAO 
{
	public List<Book> getBookDetails();
	public String getMessage();
	public void addPurchase(Purchase p);
	public List<Book> getBookByCategory(String category);
}
