package com.mindtree.bookstore.controller;

import java.time.LocalDate;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.util.SystemPropertyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.bookstore.entities.Book;
import com.mindtree.bookstore.entities.Purchase;
import com.mindtree.bookstore.service.BookService;
import com.mindtree.bookstore.service.bookServiceImpl.BookServiceImpl;

@Controller
public class BookController 
{
	public BookService bookService;
	List<Book> list;
	
	@RequestMapping(value="/begin")
	public ModelAndView displayFirst()
	{
		String msg="Hello";
		return new ModelAndView("output","message",msg);
	}
	
	@RequestMapping(value="/displaydetails")
	public ModelAndView displayBookDetails()
	{
		bookService=new BookServiceImpl();
		list=bookService.getBookDetails();
		System.out.println(list);
		return new ModelAndView("bookdetails","output",list);
	}
	
	@RequestMapping(value="/purchase")
	public String purchasePage()
	{
		System.out.println("Hello");
		//System.out.println(bookService.getMessage());
		return "purchase";
	}
	
	@RequestMapping(value="/purch")
	//public String getPurchaseDetails(HttpServletRequest req,HttpServletResponse res)
	public String getPurchaseDetails(@RequestParam int id,@RequestParam String cname,@RequestParam String mobile)
	{
		//int id=Integer.parseInt(req.getParameter("id"));
		//String name=req.getParameter("cname");
		//String mobile=req.getParameter("mobile");
		System.out.println(id+" "+cname+" "+mobile);
		bookService=new BookServiceImpl();
		list=bookService.getBookDetails();
		int pr=0;
		for(Book b:list)
		{
			if(b.getBookId()==id)
			{
				pr=b.getPrice();
				break;
			}
		}
		String today=LocalDate.now().toString();
		Purchase p=new Purchase();
		p.setCustomerName(cname);
		p.setCustomerMobileNo(mobile);
		p.setPurchaseDate(today);
		p.setAmount(pr);
		p.setBook(id);
		bookService.addPurchase(p);
		return "purchasescuccess";
	}
	
	
	@RequestMapping(value="/dispcat")
	public ModelAndView displayPurchase(@RequestParam String cat)
	{
		//String category=req.getParameter("cat");
		//System.out.println(category);
		bookService=new BookServiceImpl();
		List<Book> list1=bookService.getBookByCategory(cat);
		System.out.println(list1);
		return new ModelAndView("displaycategory","out",list1);
		
	}
	
	
}
