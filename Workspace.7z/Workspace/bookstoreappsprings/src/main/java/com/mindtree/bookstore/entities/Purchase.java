package com.mindtree.bookstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="purchase")
public class Purchase 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int purchaseId;
	
	@Column
	private String customerName;
	
	@Column
	private String customerMobileNo;
	
	@Column
	private String purchaseDate;
	
	@Column
	private int amount;
	
	@Column
	private int book;

	public Purchase() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Purchase(int purchaseId, String customerName, String customerMobileNo, String purchaseDate, int amount,
			int book) {
		super();
		this.purchaseId = purchaseId;
		this.customerName = customerName;
		this.customerMobileNo = customerMobileNo;
		this.purchaseDate = purchaseDate;
		this.amount = amount;
		this.book = book;
	}

	@Override
	public String toString() {
		return "Purchase [purchaseId=" + purchaseId + ", customerName=" + customerName + ", customerMobileNo="
				+ customerMobileNo + ", purchaseDate=" + purchaseDate + ", amount=" + amount + ", book=" + book + "]";
	}

	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerMobileNo() {
		return customerMobileNo;
	}

	public void setCustomerMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}

	public String getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getBook() {
		return book;
	}

	public void setBook(int book) {
		this.book = book;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + purchaseId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Purchase other = (Purchase) obj;
		if (purchaseId != other.purchaseId)
			return false;
		return true;
	}

	
	
}
