package com.mindtree.bookstore.service;

import java.util.List;

import com.mindtree.bookstore.entities.Book;
import com.mindtree.bookstore.entities.Purchase;

public interface BookService 
{
	public List<Book> getBookDetails();
	public String getMessage();
	public void addPurchase(Purchase p);
	public List<Book> getBookByCategory(String category);
}
