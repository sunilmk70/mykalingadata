package com.mindtree.easybucksdemo.seekassistance.dto;

public class SeekAssistanceUpdateDTO 
{
	private int seekAssistanceId;
	private int investorId;
	private int advisorId;
	private String query;
	private String answer;
	public SeekAssistanceUpdateDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SeekAssistanceUpdateDTO(int seekAssistanceId, int investorId, int advisorId, String query, String answer) {
		super();
		this.seekAssistanceId = seekAssistanceId;
		this.investorId = investorId;
		this.advisorId = advisorId;
		this.query = query;
		this.answer = answer;
	}
	@Override
	public String toString() {
		return "SeekAssistanceUpdateDTO [seekAssistanceId=" + seekAssistanceId + ", investorId=" + investorId
				+ ", advisorId=" + advisorId + ", query=" + query + ", answer=" + answer + "]";
	}
	public int getSeekAssistanceId() {
		return seekAssistanceId;
	}
	public void setSeekAssistanceId(int seekAssistanceId) {
		this.seekAssistanceId = seekAssistanceId;
	}
	public int getInvestorId() {
		return investorId;
	}
	public void setInvestorId(int investorId) {
		this.investorId = investorId;
	}
	public int getAdvisorId() {
		return advisorId;
	}
	public void setAdvisorId(int advisorId) {
		this.advisorId = advisorId;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + advisorId;
		result = prime * result + ((answer == null) ? 0 : answer.hashCode());
		result = prime * result + investorId;
		result = prime * result + ((query == null) ? 0 : query.hashCode());
		result = prime * result + seekAssistanceId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SeekAssistanceUpdateDTO other = (SeekAssistanceUpdateDTO) obj;
		if (advisorId != other.advisorId)
			return false;
		if (answer == null) {
			if (other.answer != null)
				return false;
		} else if (!answer.equals(other.answer))
			return false;
		if (investorId != other.investorId)
			return false;
		if (query == null) {
			if (other.query != null)
				return false;
		} else if (!query.equals(other.query))
			return false;
		if (seekAssistanceId != other.seekAssistanceId)
			return false;
		return true;
	}
	
}
