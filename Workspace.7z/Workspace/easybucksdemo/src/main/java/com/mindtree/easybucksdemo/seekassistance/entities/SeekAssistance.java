package com.mindtree.easybucksdemo.seekassistance.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="seek_assistance")
public class SeekAssistance 
{
	@Id
	@Column(name="seek_assistance_id")
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int seekAssistanceId;
	
	@OneToOne(targetEntity=User.class,cascade=CascadeType.ALL)
		@JoinColumn(name="investor",referencedColumnName="user_id")
	private User investor;
	
	@OneToOne(targetEntity=User.class,cascade=CascadeType.ALL)
		@JoinColumn(name="advisor",referencedColumnName="user_id")
	private User advisor;
	
	@Column(name="query")
	private String query;
	
	@Column(name="answer")
	private String answer;

	public SeekAssistance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SeekAssistance(int seekAssistanceId, User investor, User advisor, String query, String answer) {
		super();
		this.seekAssistanceId = seekAssistanceId;
		this.investor = investor;
		this.advisor = advisor;
		this.query = query;
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "SeekAssistance [seekAssistanceId=" + seekAssistanceId + ", query=" + query + ", answer=" + answer + "]";
	}

	public int getSeekAssistanceId() {
		return seekAssistanceId;
	}

	public void setSeekAssistanceId(int seekAssistanceId) {
		this.seekAssistanceId = seekAssistanceId;
	}

	public User getInvestor() {
		return investor;
	}

	public void setInvestor(User investor) {
		this.investor = investor;
	}

	public User getAdvisor() {
		return advisor;
	}

	public void setAdvisor(User advisor) {
		this.advisor = advisor;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((answer == null) ? 0 : answer.hashCode());
		result = prime * result + ((query == null) ? 0 : query.hashCode());
		result = prime * result + seekAssistanceId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SeekAssistance other = (SeekAssistance) obj;
		if (answer == null) {
			if (other.answer != null)
				return false;
		} else if (!answer.equals(other.answer))
			return false;
		if (query == null) {
			if (other.query != null)
				return false;
		} else if (!query.equals(other.query))
			return false;
		if (seekAssistanceId != other.seekAssistanceId)
			return false;
		return true;
	}
	
	
	
	
}
