package com.mindtree.easybucksdemo.seekassistance.dto;

public class SeekAssistanceDTO 
{
	private int investorId;
	private int advisorId;
	private String query;
	private String answer;
	public SeekAssistanceDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SeekAssistanceDTO(int investorId, int advisorId, String query, String answer) {
		super();
		this.investorId = investorId;
		this.advisorId = advisorId;
		this.query = query;
		this.answer = answer;
	}
	@Override
	public String toString() {
		return "SeekAssistanceDTO [investorId=" + investorId + ", advisorId=" + advisorId + ", query=" + query
				+ ", answer=" + answer + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + advisorId;
		result = prime * result + ((answer == null) ? 0 : answer.hashCode());
		result = prime * result + investorId;
		result = prime * result + ((query == null) ? 0 : query.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SeekAssistanceDTO other = (SeekAssistanceDTO) obj;
		if (advisorId != other.advisorId)
			return false;
		if (answer == null) {
			if (other.answer != null)
				return false;
		} else if (!answer.equals(other.answer))
			return false;
		if (investorId != other.investorId)
			return false;
		if (query == null) {
			if (other.query != null)
				return false;
		} else if (!query.equals(other.query))
			return false;
		return true;
	}
	public int getInvestorId() {
		return investorId;
	}
	public void setInvestorId(int investorId) {
		this.investorId = investorId;
	}
	public int getAdvisorId() {
		return advisorId;
	}
	public void setAdvisorId(int advisorId) {
		this.advisorId = advisorId;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
}
