package com.mindtree.easybucksdemo.seekassistance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucksdemo.seekassistance.dto.SeekAssistanceDTO;
import com.mindtree.easybucksdemo.seekassistance.dto.SeekAssistanceUpdateDTO;
import com.mindtree.easybucksdemo.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucksdemo.seekassistance.entities.User;
import com.mindtree.easybucksdemo.seekassistance.services.SeekAssistanceService;




@RestController
@RequestMapping(value="/seekassistance")
public class SeekAssistanceController 
{
	@Autowired
	private SeekAssistanceService seekAssistanceService;
	
	@Qualifier(value="seekAssistanceService")
	public void setSeekAssistanceService(SeekAssistanceService seekAssistanceService)
	{
		this.seekAssistanceService=seekAssistanceService;
	}
	
	@RequestMapping(value="/alldetails", method = RequestMethod.GET, produces="application/json")
	public List<SeekAssistance>  getAllSeekAssistanceDetails() {
		return this.seekAssistanceService.getALLSeekAssistanceDetails();
	}
	
	@RequestMapping(value="/addAssistance", method = RequestMethod.POST, consumes="application/json")
	public void addSeekAssistance(@RequestBody SeekAssistanceDTO seekAssistancedto) {
		
		System.out.println("Enter the dragon");
		System.out.println(seekAssistancedto);
		this.seekAssistanceService.addSeekAssistance(seekAssistancedto);
	}
	
	@RequestMapping(value="/updateAssistance", method = RequestMethod.PUT, consumes="application/json")
	public SeekAssistance updateSeekAssistanceDetail(@RequestBody SeekAssistanceUpdateDTO seekAssistanceUpdateDto) {
		System.out.println("Answer:"+seekAssistanceUpdateDto.getAnswer());
		
		return this.seekAssistanceService.updateSeekAssistanceDetail(seekAssistanceUpdateDto);
	}
	
	@RequestMapping(value="/allusers", method = RequestMethod.GET, produces="application/json")
	public List<User>  getAllAdvisors() {
		return this.seekAssistanceService.getALLAdvisorDetails();
	}
	
	@RequestMapping(value="/{seekAssistanceId}", method = RequestMethod.DELETE)
	public void deleteSong(@PathVariable("seekAssistanceId") int seekAssistanceId) {
		this.seekAssistanceService.deleteSeekAssistance(seekAssistanceId);
	}
	
}
