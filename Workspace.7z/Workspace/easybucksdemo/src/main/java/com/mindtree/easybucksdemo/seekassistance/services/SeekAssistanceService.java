package com.mindtree.easybucksdemo.seekassistance.services;

import java.util.List;

import com.mindtree.easybucksdemo.seekassistance.dto.SeekAssistanceDTO;
import com.mindtree.easybucksdemo.seekassistance.dto.SeekAssistanceUpdateDTO;
import com.mindtree.easybucksdemo.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucksdemo.seekassistance.entities.User;

public interface SeekAssistanceService 
{
	//Get all the seek assistance details
	List<SeekAssistance> getALLSeekAssistanceDetails();

	//Add new entry in seek Assistance table
	void addSeekAssistance(SeekAssistanceDTO seekAssistancedto);

		//Update Seek Assistance table
	SeekAssistance updateSeekAssistanceDetail(SeekAssistanceUpdateDTO seekAssistanceUpdateDto);

	List<User> getALLAdvisorDetails();

	void deleteSeekAssistance(int seekAssistanceId);

}
