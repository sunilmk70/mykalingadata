package com.mindtree.easybucksdemo.seekassistance.services.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucksdemo.seekassistance.dao.SeekAssistanceDAO;
import com.mindtree.easybucksdemo.seekassistance.dto.SeekAssistanceDTO;
import com.mindtree.easybucksdemo.seekassistance.dto.SeekAssistanceUpdateDTO;
import com.mindtree.easybucksdemo.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucksdemo.seekassistance.entities.User;
import com.mindtree.easybucksdemo.seekassistance.services.SeekAssistanceService;


@Service
public class SeekAssistanceServiceImpl implements  SeekAssistanceService
{
	@Autowired
	private SeekAssistanceDAO seekAssistanceDAO;
	
	public void setSeekAssistanceDAO(SeekAssistanceDAO seekAssistanceDAO) {
		this.seekAssistanceDAO = seekAssistanceDAO;
	}

	@Transactional
	public List<SeekAssistance> getALLSeekAssistanceDetails() {
		// TODO Auto-generated method stub
		return seekAssistanceDAO.getALLSeekAssistanceDetails();
	}
	@Transactional
	public void addSeekAssistance(SeekAssistanceDTO seekAssistancedto) {
		// TODO Auto-generated method stub
		User investor=new User();
		User advisor=new User();
		SeekAssistance seekAssistance=new SeekAssistance();
		investor.setUserId(1);
		advisor.setUserId(seekAssistancedto.getAdvisorId());
		seekAssistance.setInvestor(investor);
		seekAssistance.setAdvisor(advisor);
		seekAssistance.setQuery(seekAssistancedto.getQuery());
		
		this.seekAssistanceDAO.addSeekAssistance(seekAssistance);
	}
	@Transactional
	public SeekAssistance updateSeekAssistanceDetail(SeekAssistanceUpdateDTO seekAssistanceUpdatedto) {
		// TODO Auto-generated method stub
		SeekAssistance seekAssistance=new SeekAssistance();
		User investor=new User();
		User advisor=new User();
		investor.setUserId(seekAssistanceUpdatedto.getInvestorId());
		advisor.setUserId(seekAssistanceUpdatedto.getAdvisorId());
		seekAssistance.setSeekAssistanceId(seekAssistanceUpdatedto.getSeekAssistanceId());
		seekAssistance.setAdvisor(advisor);
		seekAssistance.setInvestor(investor);
		seekAssistance.setQuery(seekAssistanceUpdatedto.getQuery());
		seekAssistance.setAnswer(seekAssistanceUpdatedto.getAnswer());
		return seekAssistanceDAO.updateSeekAssistanceDetail(seekAssistance);
	}

	@Transactional
	public List<User> getALLAdvisorDetails() {
		// TODO Auto-generated method stub
		return seekAssistanceDAO.getALLAdvisorDetails();
	}

	@Transactional
	public void deleteSeekAssistance(int seekAssistanceId) {
		// TODO Auto-generated method stub
		this.seekAssistanceDAO.deleteSeekAssistance(seekAssistanceId);
	}

}
