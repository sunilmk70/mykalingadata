package com.mindtree.easybucksdemo.seekassistance.dao;

import java.util.List;


import com.mindtree.easybucksdemo.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucksdemo.seekassistance.entities.User;

public interface SeekAssistanceDAO 
{
	List<SeekAssistance> getALLSeekAssistanceDetails();
	
	void addSeekAssistance(SeekAssistance seekAssistance);

	SeekAssistance updateSeekAssistanceDetail(SeekAssistance seekAssistance);

	List<User> getALLAdvisorDetails();

	void deleteSeekAssistance(int seekAssistanceId);
	
	
}
