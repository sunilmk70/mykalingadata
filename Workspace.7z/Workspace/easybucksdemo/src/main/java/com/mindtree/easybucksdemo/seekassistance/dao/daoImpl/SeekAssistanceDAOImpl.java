package com.mindtree.easybucksdemo.seekassistance.dao.daoImpl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucksdemo.seekassistance.dao.SeekAssistanceDAO;

import com.mindtree.easybucksdemo.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucksdemo.seekassistance.entities.User;



@Repository
@Transactional
public class SeekAssistanceDAOImpl implements SeekAssistanceDAO {
	
	
private static final Logger logger = LoggerFactory.getLogger(SeekAssistanceDAOImpl.class);
	
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	public Session getSession() {
		try{
		return this.sessionFactory.getCurrentSession();
		}
		catch(HibernateException e)
		{
			return sessionFactory.openSession();
		}
	}

	
	@SuppressWarnings("unchecked")
	public List<SeekAssistance> getALLSeekAssistanceDetails() {
		List<SeekAssistance> seekAssistance = getSession().createQuery("from SeekAssistance").list();
		if(null != seekAssistance) {
			logger.info("Fetched all details successfully");
		}else {
			logger.info("Unable to fetch all details");
		}
		return seekAssistance;
	}
	
	public void addSeekAssistance(SeekAssistance seekAssistance) {
		// TODO Auto-generated method stub
		getSession().saveOrUpdate(seekAssistance);		
		logger.info("Seek Assistance is added successfully");
	}

	

	

	public SeekAssistance updateSeekAssistanceDetail(SeekAssistance seekAssistance) {
		// TODO Auto-generated method stub
		SeekAssistance seekAssistance1 = null;
		if(null!=seekAssistance) {
			getSession().update(seekAssistance);
			//getSession().saveOrUpdate(seekAssistance);
		} else{
			System.out.println("Wrong id of seekAssistance");
		}
		seekAssistance1 = getSession().load(SeekAssistance.class, new Integer(seekAssistance.getSeekAssistanceId()));
		return seekAssistance1;
	}

	@SuppressWarnings("unchecked")
	public List<User> getALLAdvisorDetails() {
		// TODO Auto-generated method stub
		List<User> user = getSession().createQuery("from User").list();
		if(null != user) {
			logger.info("Fetched all details successfully");
		}else {
			logger.info("Unable to fetch all details");
		}
		return user;
	}

	public void deleteSeekAssistance(int seekAssistanceId) {
		// TODO Auto-generated method stub
		SeekAssistance seekAssistance = getSession().load(SeekAssistance.class, new Integer(seekAssistanceId));
		if(null!=seekAssistance) {
			getSession().delete(seekAssistance);
			logger.info("SeekAssistance is deleted successfully");
		} else {
			logger.info("Unable to delete the seek assistance");
		}
	}

	

	
	

	
	

}
