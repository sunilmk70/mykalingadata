package com.mindtree.helloworld;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
 
@Controller
public class HelloWorldController 
{ 
	String name;
	@RequestMapping("/hello")  
    public ModelAndView helloWorld() 
	{  
//        String name=request.getParameter("name");  
//        String password=request.getParameter("password");  
          System.out.println("Calling 1");
//        if(password.equals("admin")){  
        //String message = name;  
       return new ModelAndView("hellopage","message",name);  
//        }  
//        else{  
//            return new ModelAndView("errorpage", "message","Sorry, username or password error");  
//        }
        
    } 
	@RequestMapping("/hello1")  
    public String helloWorld1(@RequestParam String name)
	{  
		
        //name=req.getParameter("name");  
		System.out.println(name);
//        String password=request.getParameter("password");  
//          
//        if(password.equals("admin1")){  
//        String message = "HELLO "+name;  
//        return new ModelAndView("hellopage", "message", message);  
//        }  
//        else{  
//            return new ModelAndView("errorpage", "message","Sorry, username or password error");  
//        } 
		return "redirect:/hello";
    }  
}
