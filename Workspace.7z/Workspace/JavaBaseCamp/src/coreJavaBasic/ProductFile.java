package coreJavaBasic;


import java.io.BufferedReader;
//import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class ProductFile {

	public static void main(String[] args)  throws java.io.FileNotFoundException{
     
		 try
         {
			 
      FileReader fr = new FileReader("abc.txt");
      BufferedReader br = new BufferedReader(fr);
      String s="";
      //char [] r2;
      int i=0,j=0;
      String [][]s2=new String[100][100];
      while((s = br.readLine()) != null) 
      {
      String[] s1 = s.split(",");

      for(j=0;j<s1.length;j++)
      {
       
    	  s2[i][j]=s1[j];
       
     }
     i++;
    
         }
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter the Category(Condiments/Beverages/Poultry):");
		String given = sc.next();
      
		for(i=0;i<7;i++)
		{
			if((s2[i][3].trim().equalsIgnoreCase(given)))
			{
				for(j=0;j<4;j++)
					System.out.print(s2[i][j]+" ");
				System.out.println();
			}
			continue;
			
		}
		br.close();
		sc.close();
         }
		    catch(Exception e)
		     {
		      e.printStackTrace();
		      }
	}

}
