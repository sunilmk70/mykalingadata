package coreJavaBasic;
import java.util.Scanner;
public class Triplets 
{
	public static void printTriplets(int[ ] data) 
	{
		int j,k,len=data.length;
		for(int i=0;i<len-2;i++)
		{
			for(j=i+1;j<len-1;j++)
			{
				for(k=j+1;k<len;k++)
				{
					if(data[i]+data[j]==data[k])
					{
						System.out.println("<"+data[i]+","+data[j]+","+data[k]+">");
					}
				}
			}
		}
	}
	public static void main(String[] args) 
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("How many numbers you want in array?");
		int n=scan.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=scan.nextInt();
		}
		printTriplets(arr);
		scan.close();
	}
}
