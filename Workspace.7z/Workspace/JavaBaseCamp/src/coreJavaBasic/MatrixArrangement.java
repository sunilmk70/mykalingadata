package coreJavaBasic;
import java.util.*;
public class MatrixArrangement 
{
	public static int[] arrangeElements(int[][] inputArray) 
	{ 
		int r=inputArray.length;
		int c=inputArray[0].length;
		int[] input=new int[r*c];
		int[] output=new int[r*c];
		int l=0;
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				input[l++]=inputArray[i][j];
			}
		}
		Arrays.sort(input);
		int m=input.length/2;
		if((r*c)%2==0)
			m=m-1;
		output[m]=input[0];
		int right=m+1,left=m-1;
		
		for(int i=1;i<input.length;i++)
		{
			if(i%2!=0)
				output[right++]=input[i];
			else
				output[left--]=input[i];
		}
		return output;
	}
	
	public static void main(String[] args) 
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter number of rows and columns:");
		int r=scan.nextInt();
		int c=scan.nextInt();
		int[][] arr=new int[r][c];
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				arr[i][j]=scan.nextInt();
			}
		}
		int[] output=arrangeElements(arr);
		for(int i=0;i<output.length;i++)
			System.out.print(output[i]+" ");
		scan.close();
	}

}
