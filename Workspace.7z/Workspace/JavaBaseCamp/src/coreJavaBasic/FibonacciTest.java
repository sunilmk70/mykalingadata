package coreJavaBasic;

import static org.junit.Assert.*;

import org.junit.Test;

public class FibonacciTest 
{
	@Test  
    public void testFib(){  
        assertEquals(5,NthFibonacci.fib(5));  
        assertEquals(3,NthFibonacci.fib(4));  
    }  
}
