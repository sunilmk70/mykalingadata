package com.mindtree.emphibernate.DAO;

import com.mindtree.emphibernate.entities.Employee;

public interface EmpDAO 
{
	public boolean addEmployee(Employee employee);
	public Employee getEmployee(int employeeNo);
	public void deleteEmployee(int employeeNo);
	public void updateEmployee(Employee employee);
}
