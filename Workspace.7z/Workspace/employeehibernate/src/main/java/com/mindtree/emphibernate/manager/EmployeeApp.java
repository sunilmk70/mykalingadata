package com.mindtree.emphibernate.manager;

import java.util.Scanner;

import com.mindtree.emphibernate.DAO.EmpDAO;
import com.mindtree.emphibernate.DAO.DAOImpl.EmpDAOImpl;
import com.mindtree.emphibernate.entities.Employee;

public class EmployeeApp {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		EmpDAO empdao=new EmpDAOImpl();
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Add Employee");
		System.out.println("2.Delete Employee");
		System.out.println("3.Update Employee");
		System.out.println("4.Display Employee");
		System.out.println("5.Exit");
		System.out.println("Enter ur choice");
		int choice=sc.nextInt();
		while(choice!=5)
		{
			if(choice==1)
			{
				
				Employee e=new Employee();
				System.out.println("Enter employee Name:");
				String name=sc.next();
				e.setEmployeeName(name);
				
				System.out.println("Enter employee email id:");
				String email=sc.next();
				e.setEmail(email);
				
				System.out.println("Enter birth place:");
				String birth=sc.next();
				e.setBirthplace(birth);
				
				System.out.println("Enter Salary:");
				Double salary=sc.nextDouble();
				e.setSalary(salary);
				
				empdao.addEmployee(e);
			}
			if(choice==2)
			{
				System.out.println("Which employee id details you want to delete:");
				int id=sc.nextInt();
				empdao.deleteEmployee(id);
			}
			if(choice==3)
			{
				Employee e=new Employee();
				System.out.println("Give the new employee details:");
				
				System.out.println("Enter employee Name:");
				String name=sc.next();
				e.setEmployeeName(name);
				
				System.out.println("Enter employee email id:");
				String email=sc.next();
				e.setEmail(email);
				
				System.out.println("Enter birth place:");
				String birth=sc.next();
				e.setBirthplace(birth);
				
				System.out.println("Enter Salary:");
				Double salary=sc.nextDouble();
				e.setSalary(salary);
				
				empdao.updateEmployee(e);
				
			}
			if(choice==5)
			{
				System.exit(0);
			}
			if(choice==4)
			{
				System.out.println("Which employee details you want to display?");
				int id=sc.nextInt();
				Employee e=empdao.getEmployee(id);
				System.out.println(e);
			}
			System.out.println("Enter ur choice");
			choice=sc.nextInt();
		}
		sc.close();

	}

}
