package com.mindtree.emphibernate.DAO.DAOImpl;


//import java.util.List;

import org.hibernate.HibernateException;
//import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

//import org.hibernate.query.Query;
import com.mindtree.emphibernate.DAO.EmpDAO;
import com.mindtree.emphibernate.entities.Employee;

public class EmpDAOImpl implements EmpDAO
{
	protected SessionFactory sessionFactory;
	public void setup()
	{
		final StandardServiceRegistry registry=new StandardServiceRegistryBuilder().configure().build();
		try {
			sessionFactory= new MetadataSources(registry).buildMetadata().buildSessionFactory();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}

	public boolean addEmployee(Employee employee) {
		try {
			setup();
			Session session=sessionFactory.openSession();
			session.beginTransaction();
			//session.saveOrUpdate(employee);
			session.persist(employee);
			session.getTransaction().commit();
			session.close();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public Employee getEmployee(int employeeNo) {
		try {
			String s="from Employee where employeeNo= :parameter";
			setup();
			Session session=sessionFactory.openSession();
			session.beginTransaction();
			Query<Employee> query=session.createQuery(s,Employee.class) ;
			query.setParameter("parameter",employeeNo);
			Employee e = query.getSingleResult();
			session.getTransaction().commit();
			session.close();
			return e;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} 
	
	}

	public void deleteEmployee(int employeeNo) {
		try {
			
			setup();
			Session session=sessionFactory.openSession();
			session.beginTransaction();
			Employee e=getEmployee(employeeNo);
			session.delete(e);
			session.getTransaction().commit();
			session.close();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		
	}

	public void updateEmployee(Employee employee) {
		setup();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.update(employee);
		session.getTransaction().commit();
		session.close();
		
	}

}
