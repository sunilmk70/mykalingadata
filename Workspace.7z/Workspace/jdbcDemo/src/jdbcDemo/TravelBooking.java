package jdbcDemo;
import java.sql.*;
import java.util.*;
public class TravelBooking {

	public static void main(String[] args) 
	{
		try
		{
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter Destination : ");
			String dest=scan.next();
			Class.forName("com.mysql.jdbc.Driver"); 
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/td","root","Welcome123");
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select BookingID,Source from travel where Destination='"+dest+"';");
			System.out.println("BookingID"+" |"+"Source");
			System.out.println("------------------");
			while(rs.next())
			{
				System.out.println(rs.getString("BookingID")+"    |    "+rs.getString("Source"));
			}
			scan.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
