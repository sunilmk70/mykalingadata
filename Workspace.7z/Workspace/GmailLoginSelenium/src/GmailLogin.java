import org.openqa.selenium.chrome.ChromeDriver;
public class GmailLogin {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\selenium-java-2.35.0\\chromedriver_win32_2.2\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

	}

}
