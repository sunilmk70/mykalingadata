package com.mindtree.travelapplication.manager;

import java.util.*;
import com.mindtree.travelapplication.entity.BookingDetails;
import com.mindtree.travelapplication.entity.City;
import com.mindtree.travelapplication.service.BookingService;
import com.mindtree.travelapplication.service.serviceImpl.BookingServiceImpl;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		boolean flag;
		String name;
		City destination;
		BookingService bookingService=new BookingServiceImpl();
		
		do{
			System.out.println("Enter Destination:");
			name=scan.next();
			destination=new City();
			destination.setName(name);
			flag=bookingService.checkDestination(destination);
			
		}while(flag);
		
		
		List<BookingDetails> al=bookingService.getBookingDetails(destination);
		
		
		//System.out.println("Details");
		if(al.isEmpty())
		{
			System.out.println("No details found for given destination");
		}
		else {
			System.out.println("BookingID\tSource");
			System.out.println("-------------------------");
			for(BookingDetails b:al)
			{
				System.out.println(b.getId()+"\t\t"+b.getSource().getName());
			}
			System.out.println("-------------------------");
		}
		scan.close();

	}

}
