package com.mindtree.travelapplication.service.serviceImpl;

import java.util.ArrayList;
//import java.util.List;

import com.mindtree.travelapplication.dao.BookingDAO;
import com.mindtree.travelapplication.dao.daoImpl.BookingDAOImpl;
import com.mindtree.travelapplication.entity.BookingDetails;
import com.mindtree.travelapplication.entity.City;
import com.mindtree.travelapplication.exceptions.InvalidDestinationName;
import com.mindtree.travelapplication.service.BookingService;

public class BookingServiceImpl implements BookingService
{
//getBooking Details
	private BookingDAO bookingDAO=new BookingDAOImpl();
	public ArrayList<BookingDetails> getBookingDetails(City Destination)
	{
		return bookingDAO.getBookingDetails(Destination);
	}
	public boolean checkDestination(City destination)
	{
		String name=destination.getName();
		
		for(int i=0;i<name.length();i++)
		{
			char ch=name.charAt(i);
			if(!((ch>='A' && ch<='Z')||(ch>='a' && ch<='z')||(ch==' ')))
			{
				try {
					throw new InvalidDestinationName("Invalid Destination");
				} catch (InvalidDestinationName e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					return true;
				}
				
			}
		}
		return false;
	}
}
