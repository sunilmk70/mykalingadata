package com.mindtree.travelapplication.service;
import com.mindtree.travelapplication.entity.BookingDetails;

import com.mindtree.travelapplication.entity.City;
//import com.mindtree.travelapp.utilities.*;
import java.util.*;
public interface BookingService 
{
	//interface getBookingDetails,use list
	public List<BookingDetails> getBookingDetails(City Destination);
	public boolean checkDestination(City destination);
}
