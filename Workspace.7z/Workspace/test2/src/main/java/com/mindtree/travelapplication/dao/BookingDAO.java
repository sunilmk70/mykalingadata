package com.mindtree.travelapplication.dao;
import java.util.*;

import com.mindtree.travelapplication.entity.*;
public interface BookingDAO 
{
	public String getSource(String destination);
	
	public ArrayList<BookingDetails> getBookingDetails(City Destination);
	
	
}
