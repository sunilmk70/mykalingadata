package com.mindtree.travelapplication.exceptions;
public class InvalidDestinationName extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidDestinationName(String s)
	{
		super(s);
	}
}
