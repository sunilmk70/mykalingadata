package com.mindtree.travelapplication.dao.daoImpl;
import com.mindtree.travelapplication.dao.*;
import java.sql.*;
import java.util.*;

import com.mindtree.travelapplication.entity.BookingDetails;
import com.mindtree.travelapplication.entity.City;
import com.mindtree.travelapplication.utilities.DBUtil;

public class BookingDAOImpl implements BookingDAO
{
//get booking details,statement creation
	private Statement stat=null;
	private String sql;
	private Connection conn=DBUtil.getConnection();
	public String getSource(String Destination)
	{
		return null;
	}
	public ArrayList<BookingDetails> getBookingDetails(City destination)
	{
		//System.out.println("Debug");
		ArrayList<BookingDetails> bookingDetails=new ArrayList<BookingDetails>();
		try {
			//System.out.println(conn);
			stat=conn.createStatement();
			//System.out.println("connection created");
			//System.out.println(destination.getName());
			sql="select BookingID,Source from travel where Destination='"+destination.getName()+"'";
			ResultSet rs = stat.executeQuery(sql);
			//System.out.println(rs);
			//System.out.println("Before while");
				while(rs.next())
				{
					//System.out.println("Entered while");
					BookingDetails bookingDetail=new BookingDetails();
					City sourceCity=new City();
					int bookingId=rs.getInt("BookingID");
					//System.out.println(bookingId);
					String source=rs.getString("Source");
					sourceCity.setName(source);
					bookingDetail.setId(bookingId);
					bookingDetail.setSource(sourceCity);
					bookingDetails.add(bookingDetail);
				}
				rs.close();
				DBUtil.closeConnection();
	
			
			//System.out.println(bookingDetails);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bookingDetails;
	}
}
