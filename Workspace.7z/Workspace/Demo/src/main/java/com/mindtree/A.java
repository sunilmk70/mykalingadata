package com.mindtree;

public class A 
{
	public void aFunction() throws ArithmeticException
	{
		//throw new ArithmeticException();
		int a,b,c;
		a=5;
		b=0;
		c=a/b;
		System.out.println(c);
	}
}
