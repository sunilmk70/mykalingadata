package com.mindtree;

public class C 
{
	B b = new B();
	public void cFunction()
	{
		try
		{
			b.bFunction();
		}
		catch(ArithmeticException e)
		{
			throw e;
		}
	}
}
