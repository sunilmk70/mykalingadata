package com.mindtree;

public class B
{
	A a = new A();
	public void bFunction()
	{
/*		try
		{
			a.aFunction();
		}
		catch(ArithmeticException e)
		{
			throw e;
		}
*/
		a.aFunction();
		}
}
