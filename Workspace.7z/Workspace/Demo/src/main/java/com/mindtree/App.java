package com.mindtree;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//        C c = new C();
//        try
//        {
//        	c.cFunction();
//        }
//        catch(ArithmeticException e)
//        {
//        	System.out.println("Exception caught: "+e);
//        }
    	try
    	{
    		throw new ArithmeticException();
    	}
    	catch(ArithmeticException e)
    	{
    		System.out.println("Arithmetic");
    	}
    	catch(Exception e)
    	{
    		System.out.println("Parent");
    	}
//    	catch(NullPointerException e)
//    	{
//    		System.out.println("Arithmetic");
//    	}
    }
}
