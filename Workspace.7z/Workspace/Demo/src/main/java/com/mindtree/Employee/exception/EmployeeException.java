package com.mindtree.Employee.exception;

public class EmployeeException extends Throwable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmployeeException(String s) 
	{
		super(s);
	}

}
