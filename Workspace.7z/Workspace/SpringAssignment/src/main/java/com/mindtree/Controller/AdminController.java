package com.mindtree.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.Model.Project;
import com.mindtree.Model.User;
import com.mindtree.ServiceImpl.ServiceImpl;

@Controller
public class AdminController 
{
	
	ServiceImpl service=new ServiceImpl();
 
	
	@RequestMapping(value="/a1")
	public String goToAddUser()
	{
		return "addUser";
	}
	
	@RequestMapping(value="/a2")
	public String goToAddProjects()
	{
		return "addProjects";
	}
	
	@RequestMapping(value="/a3")
	public String goToViewAllProjects()
	{
		return "viewAllProjects";
	}
	
	
	@RequestMapping(value="/a4")
	public String goToViewAllUsers()
	{
		return "viewAllUsers";
	}
	
	@RequestMapping(value="/a5")
	public String goToViewEmpById()
	{
		return "viewEmpById";
	}
	
	
	 //add project by admin
	 @RequestMapping(value="/addprojectadmin",method=RequestMethod.POST)
	 public String addProject(HttpServletRequest req,HttpServletResponse res)
	 {
		 String pname=(String)req.getParameter("pname");
		 String pdesc=(String)req.getParameter("pdesc");
		 String est=(String)req.getParameter("est");
		 Project p=new Project();
		 p.setEst(est);
		 p.setPdesc(pdesc);
		 p.setPname(pname);
		 service.addProject(p);
		 return "adminhome";
	 }
	 
	 
	 //get all projects by admin
	 @RequestMapping(value="/allprojectsadmin",method=RequestMethod.GET)
	 public String getAllProjects(Model model)
	 {
		 List al=service.getAllProjects();
		 model.addAttribute("al",al);
		 for(int i=0;i<al.size();i++)
			 System.out.println(al.get(i));
		 return "viewAllProjects";
	 }
	 
	 
	 //add user by admin
	 @RequestMapping(value="/adduseradmin",method=RequestMethod.POST)
	 public String addUser(Model model,HttpServletRequest req,HttpServletResponse res)
	 {
		 User u=new User();
		 u.setUname((String)req.getParameter("uname"));
		 u.setPassword((String)req.getParameter("password"));
		 u.setEmail((String)req.getParameter("email"));
		 u.setDoj((String)req.getParameter("doj"));
		 u.setRole((String)req.getParameter("role"));
		 u.setPname((String)req.getParameter("pname"));
		 service.addUser(u);
		 return "adminhome";
	 }
	 
	 
	 //get all users by admin
	 @RequestMapping(value="/allusersadmin",method=RequestMethod.GET)
	 public String getAllUsers(Model model)
	 {
		 List al=service.getAllUsers();
		 model.addAttribute("al",al);
		 for(int i=0;i<al.size();i++)
			 System.out.println(al.get(i));
		 return "viewAllUsers";
	 }
	 
	 
	 //get emp by id by admin
	 @RequestMapping(value="/getEmpByIdadmin",method=RequestMethod.GET)
	 public String getEmpById(Model model,@RequestParam("eid") int eid)
	 {
		 System.out.println(eid);
		 User u=service.getEmpById(eid);
		 model.addAttribute("user",u);
		 System.out.println(u);
		 return "viewEmpById";
	 }
}
