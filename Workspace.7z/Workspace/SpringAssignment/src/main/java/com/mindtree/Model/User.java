package com.mindtree.Model;

public class User 
{

	private int uid;
	private String uname;
	private String password;
	private String email;
	private String doj;
	private String role;
	private String pname;
	
	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}



	public User(int uid, String uname, String password, String email, String doj, String role, String pname) {
		super();
		this.uid = uid;
		this.uname = uname;
		this.password = password;
		this.email = email;
		this.doj = doj;
		this.role = role;
		this.pname = pname;
	}



	public int getUid() {
		return uid;
	}



	public void setUid(int uid) {
		this.uid = uid;
	}



	public String getUname() {
		return uname;
	}



	public void setUname(String uname) {
		this.uname = uname;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getDoj() {
		return doj;
	}



	public void setDoj(String doj) {
		this.doj = doj;
	}



	public String getRole() {
		return role;
	}



	public void setRole(String role) {
		this.role = role;
	}



	public String getPname() {
		return pname;
	}



	public void setPname(String pname) {
		this.pname = pname;
	}



	@Override
	public String toString() {
		return "User [uid=" + uid + ", uname=" + uname + ", email=" + email + ", doj=" + doj + ", role=" + role
				+ ", pname=" + pname + "]";
	}
	
	
	
}
