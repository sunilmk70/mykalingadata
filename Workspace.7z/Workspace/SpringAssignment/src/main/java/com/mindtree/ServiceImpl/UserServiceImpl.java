package com.mindtree.ServiceImpl;

import com.mindtree.DaoImpl.DaoImpl;
import com.mindtree.Model.Project;

public class UserServiceImpl 
{

	DaoImpl dao=new DaoImpl();
	
	
	
	public int findUser(String username,String password)
	{
		try {
			return dao.findUser(username,password);
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}
	
	
	public boolean changePassword(String password,int uid)
	{
		try {
			dao.changePassword(password,uid);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public Project getProject(int uid)
	{
		try {
			return dao.getProject(uid);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
}
