package com.mindtree.DaoImpl;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mindtree.Model.Project;
import com.mindtree.Model.User;

public class DaoImpl {
	
Connection con;
public DaoImpl()
{
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/spring","root","Welcome123");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
}


//find user
public int findUser(String username,String password) throws Exception 
{
	String sql="select * from user where username='"+username+"' and password='"+password+"'";
	Statement st=con.createStatement();
	ResultSet rs =st.executeQuery(sql);
	int uid = 0;
	if(rs.next())
	uid=rs.getInt("userid");
	return uid;
}

public User getEmpById(int uid) throws Exception
{
	String sql="select * from user where userid="+uid;
	Statement st=con.createStatement();
	ResultSet rs=st.executeQuery(sql);
	User u=new User();
	if(rs.next()){
		u.setUid(uid);
	u.setUname(rs.getString("username"));
	u.setEmail(rs.getString("email"));
	u.setDoj(rs.getString("doj"));
	u.setRole(rs.getString("role"));
	int pid=rs.getInt("pid");
	sql="select pname from project where pid="+pid;
	ResultSet rs2=st.executeQuery(sql);
	if(rs2.next())
	u.setPname(rs2.getString("pname"));
	}
	return u;
	
}


public void close() throws SQLException
{
	con.close();
}

public void addProject(Project p) throws Exception
{
	String sql="insert into project values(default,'"+p.getPname()+"','"+p.getPdesc()+"','"+p.getEst()+"')";
	Statement st=con.createStatement();
	int row=st.executeUpdate(sql);
	if(row>0)
		System.out.println("Project Added Successfully");
}


public List getAllProjects() throws Exception
{
	String sql="select * from project";
	Statement st=con.createStatement();
	ResultSet rs=st.executeQuery(sql);
	List al=new ArrayList();
	while(rs.next())
	{
			Project p = new Project();
			p.setPid(rs.getInt(1));
			p.setPname(rs.getString(2));
			p.setPdesc(rs.getString(3));
			p.setEst(rs.getString(4));
			al.add(p);
	}
	return al;
}


public void addUser(User u) throws Exception
{
	int pid=0;
	System.out.println(u.getPname());
	String sql="select pid from project where pname='"+u.getPname()+"'";
	Statement st=con.createStatement();
	ResultSet rs=st.executeQuery(sql);
	if(rs.next())
	pid=rs.getInt(1);
	sql="insert into user values(default,'"+u.getUname()+"','"+u.getPassword()+"','"+u.getDoj()+"','"+u.getRole()+"',"+pid+",'"+u.getEmail()+"')";       
	int row=st.executeUpdate(sql);
	if(row>0)
		System.out.println("User added Successfully");
}

public List getAllUsers() throws Exception  
{
	String sql="select * from user";
	Statement st=con.createStatement();
	ResultSet rs=st.executeQuery(sql);
	List al=new ArrayList();
	while(rs.next())
	{
			User u = new User();
			u.setUid(rs.getInt("pid"));
			u.setUname(rs.getString("username"));
			u.setEmail(rs.getString("email"));
			u.setDoj(rs.getString("doj"));
			u.setRole(rs.getString("role"));
			al.add(u);
	}
	return al;
}



//change Password by user
public void changePassword(String password,int uid) throws Exception
{
	String sql="update user set password='"+password+"' where userid="+uid;
	Statement st=con.createStatement();
	int row=st.executeUpdate(sql);
	if(row>0)
		System.out.println("Password changed succesfully");
}


public Project getProject(int uid) throws Exception
{
	int pid=0;
	String sql="select pid from user where userid="+uid;
	Statement st=con.createStatement();
	ResultSet rs=st.executeQuery(sql);
	if(rs.next())
		pid=rs.getInt("pid");
	sql="select * from project where pid="+pid;
	rs=st.executeQuery(sql);
	Project p=new Project();
	if(rs.next()){
		p.setPid(pid);
	p.setPname(rs.getString("pname"));
	p.setPdesc(rs.getString("pdesc"));
	p.setEst(rs.getString("est"));
	}
	return p;
}


}
