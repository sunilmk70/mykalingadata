package com.mindtree.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.Model.Project;
import com.mindtree.ServiceImpl.UserServiceImpl;


@Controller
public class UserController 
{
	UserServiceImpl service=new UserServiceImpl();
	int uid=-1;
	
	
	
	
	@RequestMapping(value="/u1")
	public String gotoChangePassword()
	{
		return "changePassword";
	}
	
	@RequestMapping(value="/u2")
	public String gotoViewProject()
	{
		return "viewUserProject";
	}
	//login check
		 @RequestMapping(value="/login",method = RequestMethod.POST)
		 public String login(Model model,@RequestParam("username") String username,@RequestParam("password") String password)
		 {
			 if(username.equalsIgnoreCase("jyoti")&&(password.equalsIgnoreCase("jyoti")))
				 return "adminhome";
			 else {
				 uid= service.findUser(username,password);
				if(uid>=0)
					return "userhome";
			 }
			 	
			 return "error";
		 }
		 
		 
	// change Password by user
	@RequestMapping(value="/changepassworduser",method=RequestMethod.POST)
	public String changePassword(Model model,@RequestParam("password") String password)
	{
		boolean flag=service.changePassword(password,uid);
		String msg;
		if(flag==true)
			msg="Password Changed Successfully";
		else
			msg="Error!!!!";
		model.addAttribute("msg",msg);
		return "changePassword";
	}
	
	@RequestMapping(value="/viewprojectuser",method=RequestMethod.GET)
	public String viewProject(Model model)
	{
		Project p=service.getProject(uid);
		model.addAttribute("p", p);
		return "viewUserProject";
	}
	
	
	
}
