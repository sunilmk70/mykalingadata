package com.mindtree.Model;

public class Project 
{

	private int pid;
	private String pname;
	private String pdesc;
	private String est;
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Project(String pname, String pdesc, String est) {
		super();
		this.pname = pname;
		this.pdesc = pdesc;
		this.est = est;
	}
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPdesc() {
		return pdesc;
	}
	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}
	public String getEst() {
		return est;
	}
	public void setEst(String est) {
		this.est = est;
	}
	@Override
	public String toString() {
		return "Project [pname=" + pname + ", pdesc=" + pdesc + ", est=" + est + "]";
	}
	
		
}
