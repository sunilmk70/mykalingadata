package com.mindtree.ServiceImpl;

import java.util.List;

import com.mindtree.DaoImpl.DaoImpl;
import com.mindtree.Model.Project;
import com.mindtree.Model.User;

public class ServiceImpl {
	
	DaoImpl dao=new DaoImpl();
	
	
	
	public User getEmpById(int eid)
	{
		try {
			return dao.getEmpById(eid);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public void addProject(Project p)
	{
		try {
			dao.addProject(p);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public List getAllProjects()
	{
		try {
			return dao.getAllProjects();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public void addUser(User u)
	{
		try {
			dao.addUser(u);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public List getAllUsers()
	{
		try {
			return dao.getAllUsers();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
