package com.mindtree.gmailselenium;



import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class App 
{
    public static void main( String[] args )
    {
    	System.setProperty("webdriver.chrome.driver", "D:/Softwares/chromedriver_win32/chromedriver.exe");
    	WebDriver driver = new ChromeDriver();
    	Logger logger = Logger.getLogger("App");
    	PropertyConfigurator.configure("log4j.properties");
        driver.get("https://www.facebook.com");
        logger.info("Successfully opened the website");
        System.out.println("Successfully opened the website");
        driver.manage().window().maximize();
        driver.findElement(By.id("email")).sendKeys("myemail");
        driver.findElement(By.id("pass")).sendKeys("mypass");
        logger.info("Successfully entered credentials");
        driver.findElement(By.id("loginbutton")).click();
        logger.info("Successfully logged in");
        System.out.println("Successfully logged in");
        
        try {
			Thread.sleep(2500);
			driver.findElement(By.id("userNavigationLabel")).click();
			Thread.sleep(2500);
			driver.findElement(By.partialLinkText("Log out")).click();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
        
        
        logger.info("Successfully logged out");
        System.out.println("Successfully logged out");
    }
}
