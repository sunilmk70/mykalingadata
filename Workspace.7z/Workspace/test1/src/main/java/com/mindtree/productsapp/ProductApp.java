package com.mindtree.productsapp;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;
import java.lang.String;

public class ProductApp 
{

	private static final String FileName = "D:\\data.txt.txt";
    public static void main(String[] args)
	{
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter catagory name:");
	  String sam=sc.next();
	  TreeSet<Product> tree=new TreeSet<Product>();
	  
	  BufferedReader br = null;
		FileReader fr = null;
        
		try {
          fr = new FileReader(FileName);
			br = new BufferedReader(fr);
            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null)
			  {
				String s[]=sCurrentLine.split(",");
				Product p=new Product();
				p.setProductId(Integer.parseInt(s[0]));
				
				//System.out.println(p.getProductId());
				
				p.setProductName(s[1]);
				p.setProductPrice(s[2]);
				p.setProductCategory(s[3]);
				tree.add(p);
			  }
            } 
		catch (IOException e) 
		{
            System.out.println("My E");
			e.printStackTrace();

		} 
		finally 
		{
             try {
                  if (br != null)
					br.close();
                  if (fr != null)
					fr.close();

			} catch (IOException ex) 
			{
                    ex.printStackTrace();
            }
       }
     Iterator<Product> it=tree.iterator();
     
     while(it.hasNext())
     {
    	 Product p1=(Product)it.next();
    	 //System.out.println(p1.getProductCategory());
    	 
    	 if((p1.getProductCategory()).equalsIgnoreCase(sam))
    	 {
    		System.out.println(p1);
    	 }
     }
     sc.close();
     
	}
}
