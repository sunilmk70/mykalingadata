package com.mindtree.playerauctionapp.manager;

public interface PlayerManager {

}
