package com.mindtree.playerauctionapp.dao;
import com.mindtree.playerauctionapp.entity.Player;
import com.mindtree.playerauctionapp.exceptions.*;
public interface PlayerDAO 
{
	void checkTeam(String team) throws InvalidTeamNameException;

	void checkCategory(Player plyr) throws InvalidCategoryException;

	void checkScore(Player plyr) throws NotABatsmenException;

	void checkFigure(Player plyr) throws NotABowlerException;

	void checkDetails(Player plyr)throws DuplicateEntryException;

	void addPlayer(Player plyr);
	
	void connClose();
			
}
