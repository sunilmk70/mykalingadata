package com.mindtree.playerauctionapp.exceptions;

public class InvalidTeamNameException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidTeamNameException(String s)
	{
		super(s);
	}
}
