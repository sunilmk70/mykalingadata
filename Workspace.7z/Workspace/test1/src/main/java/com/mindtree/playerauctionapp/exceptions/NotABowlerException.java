package com.mindtree.playerauctionapp.exceptions;

public class NotABowlerException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotABowlerException(String s)
	{
		super(s);
	}
}
