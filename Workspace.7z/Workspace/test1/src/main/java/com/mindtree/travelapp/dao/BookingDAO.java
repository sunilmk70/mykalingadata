package com.mindtree.travelapp.dao;
import java.util.*;

import com.mindtree.travelapp.entity.*;
public interface BookingDAO 
{
	public String getSource(String destination);
	
	public ArrayList<BookingDetails> getBookingDetails(City Destination);
	
	
}
