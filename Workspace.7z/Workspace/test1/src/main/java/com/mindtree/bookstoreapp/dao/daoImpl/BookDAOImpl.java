package com.mindtree.bookstoreapp.dao.daoImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.time.LocalDateTime;
import java.util.ArrayList;
//import java.util.Date;
import java.util.List;

import com.mindtree.bookstoreapp.dao.BookDAO;
import com.mindtree.bookstoreapp.entity.Book;
import com.mindtree.bookstoreapp.entity.Purchase;
import com.mindtree.bookstoreapp.exceptions.InvalidCategoryException;
import com.mindtree.travelapp.utilities.DBUtil;
import com.mysql.jdbc.PreparedStatement;

public class BookDAOImpl implements BookDAO
{
	private Statement stat=null;
	private String sql;
	private Connection conn=DBUtil.getConnection();
	
	//getting all the categories available
	public List<String> getCategory()
	{
		List<String> cat=new ArrayList<String>();
		try
		{
			stat=conn.createStatement();
			sql="select distinct CategoryName from book";
			ResultSet rs = stat.executeQuery(sql);
			while(rs.next())
			{
				cat.add(rs.getString("CategoryName"));
			}
			rs.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cat;
	}
	//getting price(amount) for given book id
	public int getAmount(int b)
	{
		int amount=0;
		try{
			
			stat=conn.createStatement();
			sql="select Price from book where BookId="+b+";";
			ResultSet rs = stat.executeQuery(sql);
			while(rs.next())
			amount=rs.getInt("Price");
			rs.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
			return amount;
	}
	
	//getting all the book details for given category
	public List<Book> getBookDetails(String category) throws InvalidCategoryException
	{
		List<Book> bookDetails=new ArrayList<Book>();
		try
		{
			stat=conn.createStatement();
			sql="select BookId from book where CategoryName='"+category+"'";
			ResultSet rs=stat.executeQuery(sql);
			if(rs.next())
			{
			sql="select * from book where CategoryName='"+category+"'";
			 rs = stat.executeQuery(sql);
			
			
				while(rs.next())
				{
				Book book=new Book();
				int bId=rs.getInt("BookId");
				String bName=rs.getString("BookName");
				String aName=rs.getString("AuthorName");
				String pName=rs.getString("PublisherName");
				String cName=rs.getString("CategoryName");
				int price=rs.getInt("Price");
				book.setBookId(bId);
				book.setBookName(bName);
				book.setAuthorName(aName);
				book.setPublisherName(pName);
				book.setCategoryName(cName);
				book.setPrice(price);
				bookDetails.add(book);
				}
			rs.close();
			}
			else
				throw new InvalidCategoryException("Invalid category name please check your input");
			
			//DBUtil.closeConnection();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bookDetails;
		
	}
	
	public List<Purchase> addPurchase(int bid,String custName,String custMobileNo,java.util.Date today,int amt)
	{
		List<Purchase> purchaseDetails=new ArrayList<Purchase>();
		java.sql.Date sqlDate = new java.sql.Date(today.getTime());
		//inserting into purchase table
		try{
			stat=conn.createStatement();
			//sql="insert into purchase(BookId,CustomerName,CustomerMobileNo,PurchaseDate,Amount) values("+bid+","+custName+","+custMobileNo+","+sqlDate+","+amt+");";
			sql="insert into purchase(BookId,CustomerName,CustomerMobileNo,PurchaseDate,Amount) values(?,?,?,?,?)";
			PreparedStatement stmt=(PreparedStatement) conn.prepareStatement(sql);
			stmt.setInt(1,bid);
			stmt.setString(2,custName);
			stmt.setString(3,custMobileNo);
			stmt.setDate(4,sqlDate);
			stmt.setInt(5,amt);
			int i=stmt.executeUpdate();
			if(i==0)
				throw new SQLException();
			//rs.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Now fetch and return purchase details
		try{
			stat=conn.createStatement();
			sql="select * from purchase";
			ResultSet rs = stat.executeQuery(sql);
			while(rs.next())
			{
				Purchase purchase=new Purchase();
				Book b=new Book();
				int pNo=rs.getInt("PurchaseNo");
				int bId=rs.getInt("BookId");
				b.setBookId(bId);
				String cName=rs.getString("CustomerName");
				String cMoNo=rs.getString("CustomerMobileNo");
				java.sql.Timestamp tod=rs.getTimestamp("PurchaseDate");
				int amount=rs.getInt("Amount");
				purchase.setPurchaseId(pNo);
				purchase.setBook(b);
				purchase.setCustomerName(cName);
				purchase.setCustomerMobileNo(cMoNo);
				//set date here
				purchase.setPurchaseDate(tod);
				purchase.setAmount(amount);
				purchaseDetails.add(purchase);
			}
			rs.close();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return purchaseDetails;
		
	}
	

}
