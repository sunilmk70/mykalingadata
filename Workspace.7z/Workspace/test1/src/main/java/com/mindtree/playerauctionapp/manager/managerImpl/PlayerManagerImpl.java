package com.mindtree.playerauctionapp.manager.managerImpl;

import com.mindtree.playerauctionapp.exceptions.*;
import com.mindtree.playerauctionapp.dao.PlayerDAO;
import com.mindtree.playerauctionapp.dao.daoImpl.PlayerDAOImpl;
import com.mindtree.playerauctionapp.entity.Player;
public class PlayerManagerImpl 
{
	PlayerDAO plint = new PlayerDAOImpl();//loose coupling
	public int checkTeam(String team) {
		try {
			plint.checkTeam(team);
			return 1;
		} catch (InvalidTeamNameException e) {
			System.out.println(e.getMessage());
		return 0;
		}
	}


	public int checkCategory(Player plyr) {
		try {
			plint.checkCategory(plyr);
			return 1;
		} 
		catch (InvalidCategoryException e) {
			System.out.println(e.getMessage());
			return 0;
		}
	}

	public void checkScore(Player plyr) {
		try {
			plint.checkScore(plyr);
		} catch (NotABatsmenException e) {
			System.out.println(e.getMessage());
			System.exit(0);
		}
	}

	public int checkFigure(Player plyr) {
		try {
			plint.checkFigure(plyr);
			return 1;
		} catch (NotABowlerException e) {
			System.out.println(e.getMessage());
			return 0;
		}
	}

	public int checkDetails(Player plyr) {
		try {
			plint.checkDetails(plyr);
			return 1;
		} catch (DuplicateEntryException e) {
			System.out.println(e.getMessage());
			return 0;
		}
	}

	public void addPlayer(Player plyr) {
		plint.addPlayer(plyr);
	}
	public void connClose()
	{
		plint.connClose();
	}
}
