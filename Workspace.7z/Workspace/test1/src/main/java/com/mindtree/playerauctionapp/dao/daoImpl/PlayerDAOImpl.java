package com.mindtree.playerauctionapp.dao.daoImpl;
import java.sql.*;
//import com.mindtree.bookstoreapp.entity.*;
import com.mindtree.playerauctionapp.dao.PlayerDAO;
import com.mindtree.playerauctionapp.entity.Player;
import com.mindtree.playerauctionapp.exceptions.*;
public class PlayerDAOImpl implements PlayerDAO
{
	Connection con=null;
	public PlayerDAOImpl()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/td","root","Welcome123");
			//System.out.println(con);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void connClose()
	{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
		
		public void checkTeam(String team) throws InvalidTeamNameException {
			try {
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select team_id from team where team_name='"+team+"'");
				if(!rs.next())
					throw new InvalidTeamNameException(team);
				else
				{
					int team_id=rs.getInt(1);
					String sql="select player_name,category from player where player_no in(select Player_no from team_player where team_id="+team_id+")";
					Statement stmt=con.createStatement();
					ResultSet rst=stmt.executeQuery(sql);
					while(rst.next())
					{
						System.out.println(rst.getString("Player_name")+ " "+rst.getString("Category"));
					}
				}
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		}


		public void checkCategory(Player plyr) throws InvalidCategoryException{
			String category=plyr.getCategory();
			if(category.equalsIgnoreCase("batsmen")||category.equalsIgnoreCase("bowler")||category.equalsIgnoreCase("Allrounder"))
				return;
			else
				throw new InvalidCategoryException("Invalid Category");
		}

		
		public void checkScore(Player plyr) throws NotABatsmenException {
			if(plyr.getCategory().equalsIgnoreCase("batsmen"))
			{
				if(plyr.getHscore()>50 && plyr.getHscore()<200)
					return;
				else
					throw new NotABatsmenException("Not a Batsmen");
			}
		}

		
		public void checkFigure(Player plyr) throws NotABowlerException {
			if(plyr.getCategory().equalsIgnoreCase("bowler"))
			{
					if(plyr.getBestfig().equalsIgnoreCase("null"))
					{
						throw new NotABowlerException("Not a Bowler");
					}
			}
		}

	
		public void checkDetails(Player plyr) throws DuplicateEntryException{
			//String category=plyr.getCategory();
			String team=plyr.getTeam();
			String name=plyr.getName();
					int team_id=0;
			try {
				Statement stmt=con.createStatement();
				ResultSet rs=stmt.executeQuery("select Team_id from team where team_name='"+team+"'");
				if(rs.next())
				 team_id=rs.getInt(1);
				String sql="select player_name from player where player_no in(select player_no from team_player where team_id="+team_id+")";
				rs=stmt.executeQuery(sql);
				while(rs.next())
				{
					if(rs.getString(1).equalsIgnoreCase(name))
					{
						throw new DuplicateEntryException("Duplicate Entry");
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		public void addPlayer(Player plyr) {
			try {
				PreparedStatement psmt=con.prepareStatement("insert into Player(Player_Name,Category,HighestScore,Bestfigure) values(?,?,?,?)");
				psmt.setString(1,plyr.getName());
				psmt.setString(2,plyr.getCategory());
				psmt.setInt(3,plyr.getHscore());
				psmt.setString(4,plyr.getBestfig());
				psmt.execute();
				int team_id=0,player_no=0;
				ResultSet rs=psmt.executeQuery("select Team_id from Team where Team_Name='"+plyr.getTeam()+"'");
				if(rs.next())
					team_id=rs.getInt(1);
				//System.out.println(team_id);
				rs=psmt.executeQuery("select player_no  from Player where player_name='"+plyr.getName()+"'");
				if(rs.next())
					player_no=rs.getInt("player_no");
				//System.out.println(count);
				psmt.execute("insert into Team_player values("+player_no+","+team_id+")");
				
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		

		
		
}

