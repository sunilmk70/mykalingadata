package com.mindtree.playerauctionapp.client;

import java.util.Scanner;

//import com.mindtree.playerauctionapp.dao.PlayerDAO;
import com.mindtree.playerauctionapp.entity.Player;
import com.mindtree.playerauctionapp.manager.managerImpl.PlayerManagerImpl;

public class PlayerAuctionClient 
{
private static Scanner sc;

public static void main(String[] args) {
		
		
		System.out.println("-------------------------Welcome to player auction portal------------------------");
		sc = new Scanner(System.in);
		Player plyr = new Player();
		PlayerManagerImpl mgr = new PlayerManagerImpl();
		String team;
		int choice,flag=1,flag1=1,flagt=1;
		while(true)
		{
			System.out.println("Enter your choice\n  1. Add Player     2. Display Player    3.  Exit");
			choice=sc.nextInt();
			
			switch (choice) {
			
			case 1:  System.out.println("Enter the Player  details");
							System.out.println("Enter Player Name: ");
							plyr.setName(sc.next());
							do
								{
									System.out.println("Enter category: ");
									plyr.setCategory(sc.next());
									flag=mgr.checkCategory(plyr);
								}while(flag==0);
							System.out.println("Enter  highest score: ");
							plyr.setHscore(sc.nextInt());
							mgr.checkScore(plyr);
							do
								{
									System.out.println("Enter best figure: (null if u want to  enter null)");
									plyr.setBestfig(sc.next());
									flag1=mgr.checkFigure(plyr);
								}while(flag1==0);
							System.out.println("Enter team name: ");
							plyr.setTeam(sc.next());
							int valid=mgr.checkDetails(plyr);
							if(valid==1)
							{
							mgr.addPlayer(plyr);
							System.out.println("User added successfully");
							}
							
				break;
				
			case 2:do{ 
						System.out.println("Enter the team name");
			         		team=sc.next();
			         		flagt=mgr.checkTeam(team);
							}while(flagt==0);
				break;

			default: mgr.connClose();
						System.exit(0);
						break;
			}
		}
		
		
}
}
