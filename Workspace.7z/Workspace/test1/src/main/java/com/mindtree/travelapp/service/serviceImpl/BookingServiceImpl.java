package com.mindtree.travelapp.service.serviceImpl;

import java.util.ArrayList;
//import java.util.List;

import com.mindtree.travelapp.dao.BookingDAO;
import com.mindtree.travelapp.dao.daoImpl.BookingDAOImpl;
import com.mindtree.travelapp.entity.BookingDetails;
import com.mindtree.travelapp.entity.City;
import com.mindtree.travelapp.exceptions.InvalidDestinationName;
import com.mindtree.travelapp.service.BookingService;

public class BookingServiceImpl implements BookingService
{
//getBooking Details
	private BookingDAO bookingDAO=new BookingDAOImpl();
	public ArrayList<BookingDetails> getBookingDetails(City Destination)
	{
		return bookingDAO.getBookingDetails(Destination);
	}
	public boolean checkDestination(City destination) 
	{
		String name=destination.getName();
		
		for(int i=0;i<name.length();i++)
		{
			char ch=name.charAt(i);
			if(!((ch>='A' && ch<='Z')||(ch>='a' && ch<='z')||(ch==' ')))
			{
				try {
					throw new InvalidDestinationName("Invalid Destination");
				} catch (InvalidDestinationName e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					return true;
				}
				
			}
		}
		return false;
	}
}


