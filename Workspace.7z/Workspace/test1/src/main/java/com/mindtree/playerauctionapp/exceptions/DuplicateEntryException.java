package com.mindtree.playerauctionapp.exceptions;

public class DuplicateEntryException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DuplicateEntryException(String s)
	{
		super(s);
	}
}
