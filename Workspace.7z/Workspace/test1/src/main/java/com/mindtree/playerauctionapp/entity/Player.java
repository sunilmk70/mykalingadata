package com.mindtree.playerauctionapp.entity;

public class Player 
{
	private String name;
	private String team;
	private String category;
	private String bestfig;
	private int hscore;
	public Player() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Player(String name, String team, String category, String bestfig, int hscore) {
		super();
		this.name = name;
		this.team = team;
		this.category = category;
		this.bestfig = bestfig;
		this.hscore = hscore;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getBestfig() {
		return bestfig;
	}
	public void setBestfig(String bestfig) {
		this.bestfig = bestfig;
	}
	public int getHscore() {
		return hscore;
	}
	public void setHscore(int hscore) {
		this.hscore = hscore;
	}
	
}
