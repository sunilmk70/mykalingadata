package com.mindtree.playerauctionapp.exceptions;

public class NotABatsmenException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotABatsmenException(String s)
	{
		super(s);
	}
}
