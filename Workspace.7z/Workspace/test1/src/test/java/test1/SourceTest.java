package test1;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.mindtree.travelapp.entity.BookingDetails;
import com.mindtree.travelapp.entity.City;
//import com.mindtree.travelapp.manager.App;
import com.mindtree.travelapp.service.BookingService;
import com.mindtree.travelapp.service.serviceImpl.BookingServiceImpl;

public class SourceTest 
{
	@Test  
    public void testFib(){
		BookingService bookingService=new BookingServiceImpl();
		City c=new City();
		c.setName("Hyderabad");
		List<BookingDetails> al=bookingService.getBookingDetails(c);
		BookingDetails b=al.get(0);
		City c1=new City();
		City c2=new City();
		c1.setName("Vijayawada");
		c2.setName("Bangalore");
        assertEquals(c1.getName(),b.getSource().getName());  
        //assertEquals(c2.getName(),b.getSource().getName());
    }  
}
