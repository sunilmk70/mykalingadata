package com.mindtree.apnadukaan.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyDukaanController 
{
	@RequestMapping(value="/mydukan")
	public ModelAndView getDukan()
	{
		String pageTitle="Welcome to my dukan";
		return new ModelAndView("display","message",pageTitle);
	}
	@RequestMapping(value="/duke")
	public String displayString(Model model)
	{
		model.addAttribute("myduke","Hello world");
		return "display";
	}
}
