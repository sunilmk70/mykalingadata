package com.mindtree.apnadukaan.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.apnadukaan.entity.Product;

@RestController
@RequestMapping(value="/dukan")
public class DukaanController 
{
	private static List<Product> products=new ArrayList<Product>();
	static
	{
		products.add(new Product(1,"Sony Bravia","It is a LED TV"));
		products.add(new Product(2,"Apple S6","It is a Great Iphone"));
		products.add(new Product(3,"Parle G","It is a Biscuit"));
		products.add(new Product(4,"LG 5400","It is a Refrigerator"));
		products.add(new Product(5,"Motorola","It is an old brand"));
	}
	@RequestMapping(value="/products", method=RequestMethod.GET)
	public List<Product> getProducts()
	{
		return products;
	}
}
