package com.mindtree.easybucks.seekassistancetests;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mindtree.easybucks.seekassistance.entities.SeekAssistance;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring/root-app-context.xml")
public class SeekAssistanceEntityTest 
{
	SeekAssistance seekAssistance=new SeekAssistance();
	@Before
	public void init()
	{
		seekAssistance.setSeekAssistanceId(1);
		seekAssistance.setInvestorId(2);
		seekAssistance.setAdvisorId(1);
		seekAssistance.setQuery("Who are you");
		seekAssistance.setAnswer("I am Test Function");
		seekAssistance.setStatus("pending");
	}
	
	@Test
	public void testGetSeekAssistanceId()
	{
		assertEquals("This is to test get seekassistance Id",1,seekAssistance.getSeekAssistanceId());
	}
	
	@Test
	public void testGetInvestorId()
	{
		assertEquals("This is to test get Investor Id",2,seekAssistance.getInvestorId());
	}
	
	@Test
	public void testGetAdvisorId()
	{
		assertEquals("This is to test get Advisor Id",1,seekAssistance.getAdvisorId());
	}
	
	@Test
	public void testGetQuery()
	{
		assertEquals("This is to test get query","Who are you",seekAssistance.getQuery());
	}
	
	@Test
	public void testGetAnswer()
	{
		assertEquals("This is to test get answer","I am Test Function",seekAssistance.getAnswer());
	}
	
	@Test
	public void testGetStatus()
	{
		assertEquals("This is to test Get Status","pending",seekAssistance.getStatus());
	}
	
	@Test
	public void testSetSeekAssistanceId()
	{
		assertEquals("Checking set Seek Assistance Id", 1, seekAssistance.getSeekAssistanceId());
	}
	
	@Test
	public void testSetInvestorId()
	{
		assertEquals("Checking set Investor Id", 2, seekAssistance.getInvestorId());
	}
	
	@Test
	public void testSetAdvisorId()
	{
		assertEquals("Checking set Advisor Id", 1, seekAssistance.getAdvisorId());
	}
	
	@Test
	public void testSetQuery()
	{
		assertEquals("Checking set Query","Who are you" , seekAssistance.getQuery());
	}
	
	@Test
	public void testSetAnswer()
	{
		assertEquals("Checking set Answer", "I am Test Function", seekAssistance.getAnswer());
	}
	
	@Test
	public void testSetStatus()
	{
		assertEquals("Checking set Status", "pending",seekAssistance.getStatus());
	}
	
}
