package com.mindtree.easybucks.seekassistancetests;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mindtree.easybucks.seekassistance.dto.SeekAssistanceUpdateDTO;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring/root-app-context.xml")
public class SeekAssistanceUpdateDtoTest 
{
	SeekAssistanceUpdateDTO seekAssistanceUpdateDto = new SeekAssistanceUpdateDTO();
	@Before
	public void init()
	{
		seekAssistanceUpdateDto.setSeekAssistanceId(1);
		seekAssistanceUpdateDto.setInvestor(2);
		seekAssistanceUpdateDto.setAdvisor(1);
		seekAssistanceUpdateDto.setQuery("Who are you");
		seekAssistanceUpdateDto.setAnswer("I am Test Function");
		seekAssistanceUpdateDto.setStatus("pending");
	}
	
	@Test
	public void testGetSeekAssistanceId()
	{
		assertEquals("This is to test get seekassistance Id",1,seekAssistanceUpdateDto.getSeekAssistanceId());
	}
	
	@Test
	public void testGetInvestor()
	{
		assertEquals("This is to test get Investor Id",2,seekAssistanceUpdateDto.getInvestor());
	}
	
	@Test
	public void testGetAdvisor()
	{
		assertEquals("This is to test get Advisor Id",1,seekAssistanceUpdateDto.getAdvisor());
	}
	
	@Test
	public void testGetQuery()
	{
		assertEquals("This is to test get query","Who are you",seekAssistanceUpdateDto.getQuery());
	}
	
	@Test
	public void testGetAnswer()
	{
		assertEquals("This is to test get answer","I am Test Function",seekAssistanceUpdateDto.getAnswer());
	}
	
	@Test
	public void testGetStatus()
	{
		assertEquals("This is to test Get Status","pending",seekAssistanceUpdateDto.getStatus());
	}
	
	@Test
	public void testSetSeekAssistanceId()
	{
		assertEquals("Checking set Seek Assistance Id", 1, seekAssistanceUpdateDto.getSeekAssistanceId());
	}
	
	@Test
	public void testSetInvestor()
	{
		assertEquals("Checking set Investor Id", 2, seekAssistanceUpdateDto.getInvestor());
	}
	
	@Test
	public void testSetAdvisor()
	{
		assertEquals("Checking set Advisor Id", 1, seekAssistanceUpdateDto.getAdvisor());
	}
	
	@Test
	public void testSetQuery()
	{
		assertEquals("Checking set Query","Who are you" , seekAssistanceUpdateDto.getQuery());
	}
	
	@Test
	public void testSetAnswer()
	{
		assertEquals("Checking set Answer", "I am Test Function", seekAssistanceUpdateDto.getAnswer());
	}
	
	@Test
	public void testSetStatus()
	{
		assertEquals("Checking set Status", "pending",seekAssistanceUpdateDto.getStatus());
	}
	
}
