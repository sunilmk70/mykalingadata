package com.mindtree.easybucks.seekassistancetests;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mindtree.easybucks.seekassistance.dto.BookAppointmentDTO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring/root-app-context.xml")
public class BookAppointmentDtoTest 
{
	BookAppointmentDTO bookAppointmentDto=new BookAppointmentDTO();
	@Before
	public void init()
	{
		bookAppointmentDto.setAdvisor(1);
		bookAppointmentDto.setAppointmentDate("10-10-2017");
		bookAppointmentDto.setInvestor(2);
		bookAppointmentDto.setPlace("Amla");
		bookAppointmentDto.setReason("Reason 1");
		bookAppointmentDto.setStatus("pending");
	}
	 @Test
	 public void testGetAdvisor()
	 {
		 assertEquals("This is to test get Advisor Id",1,bookAppointmentDto.getAdvisor());
	 }
	 
	 @Test
	 public void testGetInvestor()
	 {
		 assertEquals("This is to test get Investor Id",2,bookAppointmentDto.getInvestor());
	 }
	 
	 @Test
	 public void testGetAppointmentDate()
	 {
		 assertEquals("This is to test get Appointment Date","10-10-2017",bookAppointmentDto.getAppointmentDate());
	 }
	 
	 @Test
	 public void testGetPlace()
	 {
		 assertEquals("This is to test get Place","Amla",bookAppointmentDto.getPlace());
	 }
	 
	 @Test
	 public void testGetReason()
	 {
		 assertEquals("This is to test get Reason","Reason 1",bookAppointmentDto.getReason());
	 }
	 
	 @Test
	 public void testGetStatus()
	 {
		 assertEquals("This is to test get Status","pending",bookAppointmentDto.getStatus());
	 }
	 
	 @Test
	 public void testSetAdvisor()
	 {
		 assertEquals("This is to test Set Advisor Id",1,bookAppointmentDto.getAdvisor());
	 }
	 
	 @Test
	 public void testSetInvestor()
	 {
		 assertEquals("This is to test Set Investor Id",2,bookAppointmentDto.getInvestor());
	 }
	 
	 @Test
	 public void testSetAppointmentDate()
	 {
		 assertEquals("This is to test Set Appointment Date","10-10-2017",bookAppointmentDto.getAppointmentDate());
	 }
	 
	 @Test
	 public void testSetPlace()
	 {
		 assertEquals("This is to test Set Place","Amla",bookAppointmentDto.getPlace());
	 }
	 
	 @Test
	 public void testSetReason()
	 {
		 assertEquals("This is to test Set Reason","Reason 1",bookAppointmentDto.getReason());
	 }
	 
	 @Test
	 public void testSetStatus()
	 {
		 assertEquals("This is to test Set Status","pending",bookAppointmentDto.getStatus());
	 }
}
