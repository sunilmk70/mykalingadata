package com.mindtree.easybucks.seekassistancetests;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mindtree.easybucks.seekassistance.dto.BookAppointmentDTO;
import com.mindtree.easybucks.seekassistance.dto.BookAppointmentUpdateDTO;
import com.mindtree.easybucks.seekassistance.entities.BookAppointment;
import com.mindtree.easybucks.seekassistance.services.SeekAssistanceService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath*:spring/root-app-context.xml"})
public class BookAppointmentTest 
{
	@Autowired
	private SeekAssistanceService seekAssistanceService;
	@Test
	public void updateCheck()
	{
		BookAppointmentUpdateDTO bookAppointmentUpdateDto=new BookAppointmentUpdateDTO();
		bookAppointmentUpdateDto.setBookAppointmentId(1);
		bookAppointmentUpdateDto.setAdvisor(2);
		bookAppointmentUpdateDto.setAppointmentDate("10-10-17");
		bookAppointmentUpdateDto.setInvestor(2);
		bookAppointmentUpdateDto.setPlace("Pakistan12");
		bookAppointmentUpdateDto.setReason("Nothing");
		bookAppointmentUpdateDto.setStatus("pending");
		assertEquals(bookAppointmentUpdateDto.toString(),(seekAssistanceService.updateBookAppointment(bookAppointmentUpdateDto)).toString() );
	}
	
	@Test
	public void addCheck()
	{
		BookAppointmentDTO bookAppointmentDto = new BookAppointmentDTO();
		bookAppointmentDto.setAdvisor(1);
		bookAppointmentDto.setInvestor(2);
		bookAppointmentDto.setAppointmentDate("10-10-17");
		bookAppointmentDto.setPlace("Andaman12");
		bookAppointmentDto.setReason("Nothing");
		bookAppointmentDto.setStatus("pending");
		assertEquals(false,seekAssistanceService.addBookAppointment(bookAppointmentDto));
	}
	
	@Test
	public void deleteCheck()
	{
		assertEquals(false,seekAssistanceService.deleteBookAppointment(12345));
	}
	
	@Test
	public void allDetailsCheck()
	{
		List<BookAppointment> alldetails=new ArrayList<BookAppointment>();
		alldetails=seekAssistanceService.getALLAppointmentDetails();
		assertEquals(alldetails.size(),(seekAssistanceService.getALLAppointmentDetails()).size());
	}
}
