package com.mindtree.easybucks.seekassistancetests;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mindtree.easybucks.seekassistance.dto.SeekAssistanceDTO;


import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring/root-app-context.xml")
public class SeekAssistanceDtoTest 
{
	SeekAssistanceDTO seekAssistanceDto=new SeekAssistanceDTO();
	@Before
	public void init()
	{
		seekAssistanceDto.setInvestor(2);
		seekAssistanceDto.setAdvisor(1);
		seekAssistanceDto.setQuery("Who are you");
		seekAssistanceDto.setAnswer("I am Test Function");
		seekAssistanceDto.setStatus("pending");
	}
	
	@Test
	public void testGetInvestor()
	{
		assertEquals("This is to test get Investor Id",2,seekAssistanceDto.getInvestor());
	}
	
	@Test
	public void testGetAdvisor()
	{
		assertEquals("This is to test get Advisor Id",1,seekAssistanceDto.getAdvisor());
	}
	
	@Test
	public void testGetQuery()
	{
		assertEquals("This is to test get query","Who are you",seekAssistanceDto.getQuery());
	}
	
	@Test
	public void testGetAnswer()
	{
		assertEquals("This is to test get answer","I am Test Function",seekAssistanceDto.getAnswer());
	}
	
	@Test
	public void testGetStatus()
	{
		assertEquals("This is to test Get Status","pending",seekAssistanceDto.getStatus());
	}
	@Test
	public void testSetInvestor()
	{
		assertEquals("Checking set Investor Id", 2, seekAssistanceDto.getInvestor());
	}
	
	@Test
	public void testSetStatus()
	{
		assertEquals("Checking set Status", "pending",seekAssistanceDto.getStatus());
	}
	
	@Test
	public void testSetAdvisor()
	{
		assertEquals("Checking set Advisor Id", 1, seekAssistanceDto.getAdvisor());
	}
	
	@Test
	public void testSetQuery()
	{
		assertEquals("Checking set Query","Who are you" , seekAssistanceDto.getQuery());
	}
	
	@Test
	public void testSetAnswer()
	{
		assertEquals("Checking set Answer", "I am Test Function", seekAssistanceDto.getAnswer());
	}
	
}
