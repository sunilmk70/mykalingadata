package com.mindtree.easybucks.seekassistancetests;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mindtree.easybucks.seekassistance.dto.SeekAssistanceDTO;
import com.mindtree.easybucks.seekassistance.dto.SeekAssistanceUpdateDTO;
import com.mindtree.easybucks.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucks.seekassistance.services.SeekAssistanceService;
import com.mindtree.easybucks.signup.entity.User;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath*:spring/root-app-context.xml"})
public class SeekAssistanceTest 
{
	
	@Autowired
	private SeekAssistanceService seekAssistanceService;
	@Test
	public void updateCheck()
	{
		SeekAssistanceUpdateDTO seekAssistanceUpdateDto=new SeekAssistanceUpdateDTO();
		seekAssistanceUpdateDto.setSeekAssistanceId(1);
		seekAssistanceUpdateDto.setInvestor(4);
		seekAssistanceUpdateDto.setAdvisor(2);
		seekAssistanceUpdateDto.setQuery("Hi Sachin");
		seekAssistanceUpdateDto.setAnswer("Hi Sunil!");
		seekAssistanceUpdateDto.setStatus("pending");
		assertEquals(seekAssistanceUpdateDto.toString(),(seekAssistanceService.updateSeekAssistanceDetail(seekAssistanceUpdateDto)).toString() );
	}
	
	@Test
	public void addCheck()
	{
		SeekAssistanceDTO seekAssistanceDto=new SeekAssistanceDTO();
		seekAssistanceDto.setAdvisor(3);
		seekAssistanceDto.setInvestor(2);
		seekAssistanceDto.setQuery("Hila");
		seekAssistanceDto.setAnswer("Hello");
		seekAssistanceDto.setStatus("pending");
		assertEquals(false,seekAssistanceService.addSeekAssistance(seekAssistanceDto));
	}
	
	@Test
	public void deleteCheck()
	{
		assertEquals(false,seekAssistanceService.deleteSeekAssistance(12345));
	}
	
	@Test
	public void usersListCheck()
	{	
		List<User> users = new ArrayList<User>();
		users = seekAssistanceService.getALLUsersDetails();
		assertEquals(users.size(),(seekAssistanceService.getALLUsersDetails()).size());
	}
	
	@Test
	public void allDetailsCheck()
	{
		List<SeekAssistance> alldetails = new ArrayList<SeekAssistance>();
		alldetails = seekAssistanceService.getALLSeekAssistanceDetails();
		assertEquals(alldetails.size(),(seekAssistanceService.getALLSeekAssistanceDetails()).size());
	}
	
	
}
