package com.mindtree.easybucks.seekassistancetests;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mindtree.easybucks.seekassistance.entities.BookAppointment;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring/root-app-context.xml")
public class BookAppointmentEntityTest 
{
	BookAppointment bookAppointment = new BookAppointment();
	@Before
	public void init()
	{
		bookAppointment.setBookAppointmentId(1);
		bookAppointment.setAdvisorId(1);
		bookAppointment.setAppointmentDate("10-10-2017");
		bookAppointment.setInvestorId(2);
		bookAppointment.setPlace("Amla");
		bookAppointment.setReason("Reason 1");
		bookAppointment.setStatus("pending");
	}
	@Test
	public void testGetBookAppointmentId()
	{
		assertEquals("This is to test get Appointment Id",1,bookAppointment.getBookAppointmentId());
	}
	
	@Test
	 public void testGetAdvisorId()
	 {
		 assertEquals("This is to test get Advisor Id",1,bookAppointment.getAdvisorId());
	 }
	 
	 @Test
	 public void testGetInvestorId()
	 {
		 assertEquals("This is to test get Investor Id",2,bookAppointment.getInvestorId());
	 }
	 
	 @Test
	 public void testGetAppointmentDate()
	 {
		 assertEquals("This is to test get Appointment Date","10-10-2017",bookAppointment.getAppointmentDate());
	 }
	 
	 @Test
	 public void testGetPlace()
	 {
		 assertEquals("This is to test get Place","Amla",bookAppointment.getPlace());
	 }
	 
	 @Test
	 public void testGetReason()
	 {
		 assertEquals("This is to test get Reason","Reason 1",bookAppointment.getReason());
	 }
	 
	 @Test
	 public void testGetStatus()
	 {
		 assertEquals("This is to test get Status","pending",bookAppointment.getStatus());
	 }
	 
	 @Test
		public void testSetBookAppointmentId()
		{
			assertEquals("This is to test Set Appointment Id",1,bookAppointment.getBookAppointmentId());
		}
	 
	 @Test
	 public void testSetAdvisorId()
	 {
		 assertEquals("This is to test Set Advisor Id",1,bookAppointment.getAdvisorId());
	 }
	 
	 @Test
	 public void testSetInvestorId()
	 {
		 assertEquals("This is to test Set Investor Id",2,bookAppointment.getInvestorId());
	 }
	 
	 @Test
	 public void testSetAppointmentDate()
	 {
		 assertEquals("This is to test Set Appointment Date","10-10-2017",bookAppointment.getAppointmentDate());
	 }
	 
	 @Test
	 public void testSetPlace()
	 {
		 assertEquals("This is to test Set Place","Amla",bookAppointment.getPlace());
	 }
	 
	 @Test
	 public void testSetReason()
	 {
		 assertEquals("This is to test Set Reason","Reason 1",bookAppointment.getReason());
	 }
	 
	 @Test
	 public void testSetStatus()
	 {
		 assertEquals("This is to test Set Status","pending",bookAppointment.getStatus());
	 }
}
