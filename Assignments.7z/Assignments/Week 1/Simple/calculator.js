var val1=parseInt(document.getElementById("value1").value);
var val2=parseInt(document.getElementById("value2").value);
function addNumbers()
                {                        
						let sel=document.getElementById("s");
                        let ans=document.getElementById("answer");
						if(sel.value=="add")
                        	ans.value=val1+val2;
						if(sel.value=="sub")
                        	ans.value=val1-val2;
						if(sel.value=="mult")
                        	ans.value=val1*val2;
                }
function checkNum()
{
	if(isNaN(val1)||isNaN(val2))
		alert("Please enter only numericals");
}    