function callit(a)
{
	if(a == "select")
	{
		document.getElementById("tab").innerHTML ="<table><tr><th>Product id</th><th>Product name</th><th>Price</th></tr>";
	}
	if(a == "mobile")
	{
		document.getElementById("tab").innerHTML = "<table><tr><th>Product id</th><th>Product name</th><th>Price</th></tr><tr><td>001</td><td>Apple</td><td>50K</td></tr><tr><td>002</td><td>Samsung</td><td>40K</td></tr></table>";
	}
	if(a == "camera")
	{
		document.getElementById("tab").innerHTML = "<table><tr><th>Product id</th><th>Product name</th><th>Price</th></tr><tr><td>011</td><td>Nikon</td><td>50K</td></tr><tr><td>012</td><td>Sony</td><td>40K</td></tr></table>";
	}
	if(a == "laptop")
	{
		document.getElementById("tab").innerHTML = "<table><tr><th>Product id</th><th>Product name</th><th>Price</th></tr><tr><td>021</td><td>Dell</td><td>50K</td></tr><tr><td>022</td><td>Acer</td><td>40K</td></tr></table>";
	}
}
