Week 1 Simple Assignments

Open index.html to view pages