function emailvalid()
{
	let em = document.getElementById("10");
	let me = "^[a-z0-9]{1,10}@[a-z]{3,8}.[a-z]{2,3}$";
	if(!((em.value).match(me)))
	{
		document.getElementById("mem").innerHTML=" *Invalid*";
		em.value=" ";
		//document.getElementById("10").focus();
	}
	else
	{
		document.getElementById("mem").innerHTML=" ";
	}
}
function pinvalid()
{
	let pc= document.getElementById("6");
	let mp = "^[0-9]{6}$";
	if(!((pc.value).match(mp)))
	{
		document.getElementById("mpc").innerHTML=" *Invalid*";
		pc.value=" ";
		//document.getElementById("6").focus();
	}
	else
	{
		document.getElementById("mpc").innerHTML=" ";
	}
}