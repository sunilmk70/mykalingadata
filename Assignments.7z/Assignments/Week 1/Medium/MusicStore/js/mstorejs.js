var songsArray = [];
function onAddPressed() 
{  
                var sName = document.getElementById("uname").value
                var aName = document.getElementById("aname").value
                var uName = document.getElementById("lname").value
                var alName = document.getElementById("alname").value
                var dName = document.getElementById("dname").value
                var tName = document.getElementById("tname").value
                              
                var songObj = {"songName": sName, "artistName": aName, "urlName": uName, "albumName": alName, "durationName":dName,"tagsName":tname};
                var old=JSON.parse(localStorage.getItem("songsRecord"));
                if(old==null)
                        old=[];
                old.push(songObj);
                localStorage.songsRecord = JSON.stringify(old);
                alert("Song added successfully");
}

function onLoad()
{
        if(localStorage.songsRecord) 
        {
                var d=document.getElementById("slist");
                let dis='<table cellspacing="0" ><tr><th><b>Song</b></th><th><b>Select</b></th></tr>';
                songsArray = JSON.parse(localStorage.songsRecord);
                for (var i = 0; i < songsArray.length; i++) 
                {
                        dis+='<tr><td>'+songsArray[i].songName+'</td><td><input type="checkbox" value='+songsArray[i].songName+' id='+i+'></td></tr>';
                        //document.getElementById("slist").innerHTML+=''+'<b>'+(i+1)+'</b>'+'.'+songsArray[i].songName+'<input type="checkbox" value='+songsArray[i].songName+' id='+i+' ><br>';
                }
                 //document.getElementById("slist").innerHTML+='<hr>';
                 dis+='</table>';
                 d.innerHTML=dis;
        }
        if(localStorage.playRecord)
        {
                var di=document.getElementById("dsplist");
                let disp='<table cellspacing="0" ><tr><th>Playlist</th><th>Song</th></tr>';
                playArray = JSON.parse(localStorage.playRecord);
                for(let x=0;x<playArray.length;x++)
                {
                        //document.getElementById("dsplist").innerHTML+='<b>'+playArray[x].plname+'</b> : '+playArray[x].song+'<br>';
                        disp+='<tr><td>'+playArray[x].plname+'</td><td>'+playArray[x].song+'</td></tr>';
                }
                //document.getElementById("dsplist").innerHTML+='<hr>';
                disp+='</table>';
                di.innerHTML=disp;
        }


}

function createPlayList()
{
        var plname=document.getElementById("plname").value;
        var plArray=[];
        let tag=0;
        plArray=JSON.parse(localStorage.playRecord);
        for(let y=0;y<plArray.length;y++)
        {
                 if(plname==plArray[y].plname)
                 {
                         tag=1;
                         break;
                 }
         }
        if(tag==0)
        {
                let slen=songsArray.length;
                for(let q=0;q<slen;q++)
                {
                        if(document.getElementById(""+q+"").checked==true)
                        {                       
                                var song=document.getElementById(""+q+"").value;
                                var playObj = {plname,song};
                                var old1=JSON.parse(localStorage.getItem("playRecord"));
                                if(old1==null)
                                        old1=[];
                                old1.push(playObj);
                                localStorage.playRecord = JSON.stringify(old1);
                        }
                }
                location.reload();
                location.href="mstorehome.html";
                alert("Playlist added successfully!!!");
        }
         else
         {
                 alert("Playlist already exists.Select another name");
                 document.getElementById("plname").value="";
         }

}