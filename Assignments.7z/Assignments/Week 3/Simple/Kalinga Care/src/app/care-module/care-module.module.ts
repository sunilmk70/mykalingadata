import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IcuComponent } from './icu/icu.component';
import { HeartComponent } from './heart/heart.component';
import { OrthopedicsComponent } from './orthopedics/orthopedics.component';
import { EmergencyComponent } from './emergency/emergency.component';
import { CareRoutingModule } from "./care-routing.module";
import { SidebarComponent } from './sidebar/sidebar.component';

@NgModule({
  imports: [
    CommonModule,
    CareRoutingModule

  ],
  declarations: [IcuComponent, HeartComponent, OrthopedicsComponent, EmergencyComponent, SidebarComponent]
})
export class CareModule{ }
