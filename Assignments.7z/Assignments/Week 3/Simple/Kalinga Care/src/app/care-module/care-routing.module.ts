import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { IcuComponent } from "./icu/icu.component";
import { OrthopedicsComponent } from "./orthopedics/orthopedics.component";
import { EmergencyComponent } from "./emergency/emergency.component";
import { HeartComponent } from "./heart/heart.component";
import { SidebarComponent } from "./sidebar/sidebar.component";

const routes:Routes=[
{path:'',component:SidebarComponent,
children:[
{path:'icu',component:IcuComponent},
{path:'emergency',component:EmergencyComponent},
{path:'heart',component:HeartComponent},
{path:'orthopedics',component:OrthopedicsComponent}
]},

]
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class CareRoutingModule { }
