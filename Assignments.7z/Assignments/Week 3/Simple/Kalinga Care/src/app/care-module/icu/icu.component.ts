import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-icu',
  templateUrl: './icu.component.html',
  styleUrls: ['./icu.component.css']
})
export class IcuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
