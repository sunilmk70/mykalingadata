import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
const routes:Routes=[
  {path:'',loadChildren:'./home-module/home-module.module#HomeModule'},
  {path:'care',loadChildren:'./care-module/care-module.module#CareModule'}
]
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
