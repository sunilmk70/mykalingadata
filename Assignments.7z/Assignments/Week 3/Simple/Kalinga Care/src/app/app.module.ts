import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeModule } from "./home-module/home-module.module";
import { CareModule } from "./care-module/care-module.module";

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HomeModule,
    CareModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
