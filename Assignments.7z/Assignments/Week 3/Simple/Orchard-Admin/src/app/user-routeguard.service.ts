import { Injectable }     from '@angular/core';
import { CanActivate }    from '@angular/router';

@Injectable()
export class UserRouteGuard implements CanActivate 
{
    isAllowed:boolean;
    isUserAllowed(user:boolean)
    {
        this.isAllowed=user;
    }
  canActivate() 
  {
      if(this.isAllowed==false)
      {
            window.alert("Access Denied!! You are not allowed to visit this page.");
            return false;
      }
      else
      {
            return true;
      }
  }
}