import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from "@angular/router";
import { UserRouteGuard } from "../user-routeguard.service";
declare var require: any;

@Component({
  selector: 'app-landingpage',
  templateUrl: './landingpage.component.html',
  styleUrls: ['./landingpage.component.css']
})
export class LandingpageComponent implements OnInit {
  test:any;

  isCampusMind:boolean=false;
  isLead:boolean=false;

  


  mid:string;
  pwd:string;
  constructor(private router:Router,private routerGuard:UserRouteGuard) { }

  ngOnInit() 
  {
    this.test = require('../../jsonfiles/credentials.json');
  }

  Login()
  {
    if((this.mid==this.test[0].mid) && (this.pwd==this.test[0].password) && (this.test[0].role=='CampusMind'))
    {
      console.log(this.test[0].role+" logged in");
      this.routerGuard.isUserAllowed(false);
      this.router.navigate(['userpage']);
    }
    else if((this.mid==this.test[1].mid) && (this.pwd==this.test[1].password) && (this.test[1].role=='Lead'))
    {
      console.log(this.test[1].role+" logged in");
      this.router.navigate(['userpage']);
    }
    else
    {
      console.log("Invalid Credentials");
      window.alert("Access Denied!! Invalid Credentials!!!");
    }
    
  }

  clear()
  {
    this.mid='';
    this.pwd='';
  }

}
