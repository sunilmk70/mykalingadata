import { Component, OnInit } from '@angular/core';
declare var require: any
@Component({
  selector: 'app-lead',
  templateUrl: './lead.component.html',
  styleUrls: ['./lead.component.css']
})
export class LeadComponent implements OnInit {
test:any;
  constructor() { }

  ngOnInit() {
     this.test = require('../../jsonfiles/CampusMinds.json');
  }

}
