import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserpageComponent } from "./userpage/userpage.component";
import { LandingpageComponent } from "./landingpage/landingpage.component";
import { LeadComponent } from "./lead/lead.component";
import { CampusmindComponent } from "./campusmind/campusmind.component";
import { CapabilitiesComponent } from "./capabilities/capabilities.component";
import { UserRouteGuard } from "./user-routeguard.service";

const routes: Routes = [
  {path : '', component: LandingpageComponent},
  {path : 'userpage', component : UserpageComponent,
    children:[
      {path: '', component:CapabilitiesComponent},
      {path : 'lead', component:LeadComponent, canActivate:[UserRouteGuard]},
      {path : 'campusmind', component: CampusmindComponent},
      {path : 'capabilities', component:CapabilitiesComponent}
    ]
  },
  {path : 'logout',component: LandingpageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
