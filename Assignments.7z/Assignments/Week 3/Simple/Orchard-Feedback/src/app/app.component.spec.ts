import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { FeedbackComponent } from "./feedback/feedback.component";
import { FeedbackcommentsComponent } from "./feedbackcomments/feedbackcomments.component";
import { FeedbackformComponent } from "./feedbackform/feedbackform.component";
import { FormsModule } from "@angular/forms";
import { FeedbackService } from "./feedback.service";
import { ShadowDirective } from "./feedbackform/shadow.directive";
describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        FeedbackComponent,
        FeedbackcommentsComponent,
        FeedbackformComponent,
        ShadowDirective
      ],
      imports:[FormsModule],
      providers:[FeedbackService]
    }).compileComponents();
  }));
  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
});
