import { Component, OnInit } from '@angular/core';
import { Feedback } from "../feedback";
import { FeedbackService } from "../feedback.service";

@Component({
  selector: 'app-feedbackcomments',
  templateUrl: './feedbackcomments.component.html',
  styleUrls: ['./feedbackcomments.component.css']
})
export class FeedbackcommentsComponent implements OnInit {

  feedback:Feedback[];
  constructor(private feedbackService:FeedbackService) { }

  ngOnInit() {
    this.feedbackService.goal.subscribe((data)=>{
      this.feedback=data;
    });
  }

}
