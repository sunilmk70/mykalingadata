import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbackcommentsComponent } from './feedbackcomments.component';
import { FeedbackService } from "../feedback.service";

describe('FeedbackcommentsComponent', () => {
  let component: FeedbackcommentsComponent;
  let fixture: ComponentFixture<FeedbackcommentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeedbackcommentsComponent ],
      providers:[FeedbackService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedbackcommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
