import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { FeedbackformComponent } from './feedbackform/feedbackform.component';
import { FeedbackcommentsComponent } from './feedbackcomments/feedbackcomments.component';
import { FeedbackService } from "./feedback.service";
import { ShadowDirective } from "./feedbackform/shadow.directive";


@NgModule({
  declarations: [
    AppComponent,
    FeedbackComponent,
    FeedbackformComponent,
    FeedbackcommentsComponent,
    ShadowDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [FeedbackService],
  bootstrap: [AppComponent]
})
export class AppModule { }
