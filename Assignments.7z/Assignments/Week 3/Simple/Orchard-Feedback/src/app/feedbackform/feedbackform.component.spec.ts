import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbackformComponent } from './feedbackform.component';
import { FormsModule } from "@angular/forms";
import { ShadowDirective } from "./shadow.directive";
import { FeedbackService } from "../feedback.service";

describe('FeedbackformComponent', () => {
  let component: FeedbackformComponent;
  let fixture: ComponentFixture<FeedbackformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeedbackformComponent,ShadowDirective ],
      imports:[FormsModule],
      providers:[FeedbackService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedbackformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('clear method should clear data', () => {
  component.name="Sunil Methra";
  component.comments="Good Website!";
  component.mid="M1043073";
  component.clear();
  expect(component.name).toBe("");
  expect(component.mid).toBe("");
  expect(component.comments).toBe("");
}); 
});
