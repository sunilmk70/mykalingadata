import { Directive, ElementRef, Renderer2, Input, OnInit } from '@angular/core';

@Directive({ selector: '[boxShadow]' })
export class ShadowDirective implements OnInit
{
    @Input() boxShadow: string;
    @Input() boxShadowX: string;
    @Input() boxShadowY: string;
    @Input() boxShadowBlur: string;
    constructor(private elem: ElementRef,private renderer: Renderer2) 
    {
       //renderer.setStyle(elem.nativeElement, 'box-shadow', '2px 2px 12px #58A362');
    }
    ngOnInit() 
    {
        let boxShadowStr = `${ this.boxShadowX } ${ this.boxShadowY } ${ this.boxShadowBlur } ${ this.boxShadow }`;
        this.renderer.setStyle(this.elem.nativeElement, 'box-shadow', boxShadowStr);
    }
} 
