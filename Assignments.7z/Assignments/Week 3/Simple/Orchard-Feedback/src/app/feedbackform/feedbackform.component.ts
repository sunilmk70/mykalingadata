import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Feedback } from "../feedback";
import { FeedbackService } from "../feedback.service";



@Component({
  selector: 'app-feedbackform',
  templateUrl: './feedbackform.component.html',
  styleUrls: ['./feedbackform.component.css']
})
export class FeedbackformComponent implements OnInit {
name:string;
mid:string;
comments:string;
  

  constructor(private feedbackService:FeedbackService) { 
    

  }

  onSubmit()
  {   
    //console.log(this.name);
      this.feedbackService.feedback.push(new Feedback(this.name,this.mid,this.comments,new Date()));
  }
  
  clear()
  {
      this.name='';
      this.mid='';
      this.comments='';
  }

  ngOnInit() {
  }

}
