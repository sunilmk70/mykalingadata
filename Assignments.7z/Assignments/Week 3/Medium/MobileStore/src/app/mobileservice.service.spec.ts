import { TestBed, inject } from '@angular/core/testing';

import { MobileserviceService } from './mobileservice.service';
import { Injectable } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';

describe('MobileserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      //declarations:[HttpClient,Observable],
      providers: [MobileserviceService],
      imports:[HttpClientModule]
    });
  });

  it('should be created', inject([MobileserviceService], (service: MobileserviceService) => {
    expect(service).toBeTruthy();
  }));
});
