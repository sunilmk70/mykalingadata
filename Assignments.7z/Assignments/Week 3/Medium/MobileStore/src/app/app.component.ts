import { Component ,OnInit } from '@angular/core';
import { MobileserviceService } from "./mobileservice.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  mobiles: any = '';
  mob: any;
  name: any;
  desc: any;
  pic: any;

  constructor(private service: MobileserviceService) { }

  ngOnInit() {
    this.getMobiles();
  }

  getMobiles(): any {
    this.service.getMobilessFromApi().subscribe(
      data => {
        this.mobiles = data;
      });
  }

  openModal(m) {
    this.mob = m;
    this.name = this.mob.mob_name;
    this.pic = this.mob.mob_img;
    this.desc = this.mob.desc;
  }

  clearFilters() {
    (<HTMLInputElement>document.getElementById("M1")).checked = false;
    (<HTMLInputElement>document.getElementById("M2")).checked = false;
    (<HTMLInputElement>document.getElementById("M3")).checked = false;
    (<HTMLInputElement>document.getElementById("M4")).checked = false;
    (<HTMLInputElement>document.getElementById("M5")).checked = false;

    (<HTMLInputElement>document.getElementById("S1")).checked = false;
    (<HTMLInputElement>document.getElementById("S2")).checked = false;

    (<HTMLInputElement>document.getElementById("O2")).checked = false;
    (<HTMLInputElement>document.getElementById("O1")).checked = false;
    (<HTMLInputElement>document.getElementById("O3")).checked = false;

    (<HTMLInputElement>document.getElementById("p1")).style.opacity = '1';
    (<HTMLInputElement>document.getElementById("p2")).style.opacity = '1';
    (<HTMLInputElement>document.getElementById("p3")).style.opacity = '1';
    (<HTMLInputElement>document.getElementById("p4")).style.opacity = '1';
    (<HTMLInputElement>document.getElementById("p5")).style.opacity = '1';
    (<HTMLInputElement>document.getElementById("p6")).style.opacity = '1';

  }

  filter() {
    let apple = (<HTMLInputElement>document.getElementById("M1")).checked;
    let samsung = (<HTMLInputElement>document.getElementById("M2")).checked;
    let htc = (<HTMLInputElement>document.getElementById("M3")).checked;
    let nokia = (<HTMLInputElement>document.getElementById("M4")).checked;
    let sony = (<HTMLInputElement>document.getElementById("M5")).checked;

    let gb16 = (<HTMLInputElement>document.getElementById("S1")).checked;
    var gb32 = (<HTMLInputElement>document.getElementById("S2")).checked;

    let ios = (<HTMLInputElement>document.getElementById("O2")).checked;
    let android = (<HTMLInputElement>document.getElementById("O1")).checked;
    let windows = (<HTMLInputElement>document.getElementById("O3")).checked;





    if (apple) { 
      console.log('apple'+apple);
      for(let i=0;i<this.mobiles.length;i++){
        if(this.mobiles[i].manufacturer==='Apple'){
          console.log(this.mobiles[i].id+':'+i);
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '1';
        }
        else{
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '0.1';
        }
      }
    } 

    if (samsung) { 
      console.log('samsung'+samsung);
      for(let i=0;i<this.mobiles.length;i++){
        if(this.mobiles[i].manufacturer==='Samsung'){
          console.log(this.mobiles[i].id+':'+i);
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '1';
        }
        else{
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '0.1';
        }
      }
    }

    if (htc) { 
      console.log('htc'+htc);
      for(let i=0;i<this.mobiles.length;i++){
        if(this.mobiles[i].manufacturer==='HTC'){
          console.log(this.mobiles[i].id+':'+i);
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '1';
        }
        else{
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '0.1';
        }
      }
    } 

    if (nokia) { 
      console.log('nokia'+nokia);
      for(let i=0;i<this.mobiles.length;i++){
        if(this.mobiles[i].manufacturer==='Nokia'){
          console.log(this.mobiles[i].id+':'+i);
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '1';
        }
        else{
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '0.1';
        }
      }
    } 

    if (sony) { 
      console.log('sony'+sony);
      for(let i=0;i<this.mobiles.length;i++){
        if(this.mobiles[i].manufacturer==='Sony'){
          console.log(this.mobiles[i].id+':'+i);
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '1';
        }
        else{
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '0.1';
        }
      }
    } 

    if (gb16) { 
      console.log('16gb'+gb16);
      for(let i=0;i<this.mobiles.length;i++){
        if(this.mobiles[i].storage==='16GB'){
          console.log(this.mobiles[i].id+':'+i);
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '1';
        }
        else{
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '0.1';
        }
      }
    } 

    if (gb32) { 
      console.log('32gb'+gb32);
      for(let i=0;i<this.mobiles.length;i++){
        if(this.mobiles[i].storage==='32GB'){
          console.log(this.mobiles[i].id+':'+i);
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '1';
        }
        else{
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '0.1';
        }
      }
    } 

    if (windows) { 
      console.log('windows'+windows);
      for(let i=0;i<this.mobiles.length;i++){
        if(this.mobiles[i].os==='Windows'){
          console.log(this.mobiles[i].id+':'+i);
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '1';
        }
        else{
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '0.1';
        }
      }
    } 

    if (android) { 
      console.log('android'+android);
      for(let i=0;i<this.mobiles.length;i++){
        if(this.mobiles[i].os==='Android'){
          console.log(this.mobiles[i].id+':'+i);
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '1';
        }
        else{
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '0.1';
        }
      }
    } 

    if (ios) { 
      console.log('ios'+ios);
      for(let i=0;i<this.mobiles.length;i++){
        if(this.mobiles[i].os==='iOS'){
          console.log(this.mobiles[i].id+':'+i);
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '1';
        }
        else{
          (<HTMLInputElement>document.getElementById(this.mobiles[i].id)).style.opacity = '0.1';
        }
      }
    } 
  
  }  

}
