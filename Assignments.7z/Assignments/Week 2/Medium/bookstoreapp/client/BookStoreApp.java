package com.mindtree.bookstoreapp.client;

//import java.time.LocalDateTime;
//import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.mindtree.bookstoreapp.entity.Book;
import com.mindtree.bookstoreapp.entity.Purchase;
//import com.mindtree.bookstoreapp.exceptions.InvalidCategoryException;
import com.mindtree.bookstoreapp.manager.BookStoreManager;
import com.mindtree.bookstoreapp.manager.managerImpl.BookStoreManagerImpl;


public class BookStoreApp {

	public static void main(String[] args) 
	{
		BookStoreManager bookManager=new BookStoreManagerImpl();
		Scanner scan=new Scanner(System.in);
		System.out.println("XYZ Book Store\n--------------");
		System.out.println("1.Display Book Details");
		System.out.println("2.Purchase a Book");
		System.out.println("3.Exit");
		System.out.println("Enter your choice:");
		int choice=scan.nextInt();
		while(choice!=3)
		{
			if(choice==1)
			{
				List<String> category=bookManager.getCategory();
				if(category.isEmpty())
				{
				System.out.println("No Categories Available");
				}
				else
				{
					System.out.println("List of categories available:");
					System.out.print("[");
					for(String b:category)
					{
						System.out.print(b+",");
					}
					System.out.print("]");
				}
				System.out.println();
				System.out.println("Which Category Details you want to see?");
				String cat=scan.next();
				List<Book> books=null;
			
				books=bookManager.getBookDetails(cat);
				if(books==null)
					System.exit(0);
				
				if(books.isEmpty())
				{
					System.out.println("No Details to Display for Category:"+cat);
				}
				else
				{
					System.out.println("ID\tName\t\t\tAuthor\t\tPublisher\tPrice");
					for(Book b:books)
					{
						System.out.println(b.getBookId()+"\t"+b.getBookName()+"\t\t"+b.getAuthorName()+"\t\t"+b.getPublisherName()+"\t"+b.getPrice());
					}
				}
			}
			else if(choice==2)
			{
				//purchase a book
				System.out.println("Enter Book ID:");
				int bid=scan.nextInt();
				//LocalDateTime today=java.time.LocalDateTime.now();
				Book b=new Book();
				b.setBookId(bid);
				System.out.println("Enter Customer Name:");
				String custName=scan.next();
				System.out.println("Enter Customer Mobile Number:");
				String custMobileNo=scan.next();
				//int id;
				int amt=bookManager.getAmount(bid);
				java.util.Date date = new java.util.Date();
				//System.out.println(date);
				//If purchased successfully
				System.out.println("Book Purchased Successfully");
				List<Purchase> purchase=bookManager.addPurchase(bid,custName,custMobileNo,date,amt);
				//display purchased id and amount
				for(Purchase p:purchase)
				{
					System.out.println("Purchase Number:"+p.getPurchaseId()+"\nPurchase Date:"+p.getPurchaseDate()+"\nPurchase Amount:"+p.getAmount());
				}
				
			}
			else
			{
				System.out.println("Thank you! Visit Again");
				System.exit(0);
			}
			System.out.println("Enter your choice:");
			choice=scan.nextInt();
		}
		scan.close();
	}

}
