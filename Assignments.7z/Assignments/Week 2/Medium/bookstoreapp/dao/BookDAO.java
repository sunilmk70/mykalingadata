package com.mindtree.bookstoreapp.dao;
import java.util.Date;
//import java.util.Date;
import java.util.List;
import com.mindtree.bookstoreapp.entity.Book;
import com.mindtree.bookstoreapp.entity.Purchase;
import com.mindtree.bookstoreapp.exceptions.InvalidCategoryException;
//import com.mindtree.bookstoreapp.entity.Purchase;
public interface BookDAO 
{
	public List<Book> getBookDetails(String category)throws InvalidCategoryException;
	public List<String> getCategory();
	public int getAmount(int b);
	public List<Purchase> addPurchase(int bid,String custName,String custMobileNo,Date today,int amt);
	//public int purchaseBook(int purchaseNo,Book bookId,String customerName,String customerMobileNo,Date purchaseDate,int amount);
//	public List<Purchase> storePurchase(Book b,String custName,String custMobileNo);
}
