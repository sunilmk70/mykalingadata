package com.mindtree.bookstoreapp.manager.managerImpl;

//import java.time.LocalDateTime;
//import java.util.Date;
import java.util.List;

import com.mindtree.bookstoreapp.dao.BookDAO;
import com.mindtree.bookstoreapp.dao.daoImpl.BookDAOImpl;
import com.mindtree.bookstoreapp.entity.Book;
import com.mindtree.bookstoreapp.entity.Purchase;
import com.mindtree.bookstoreapp.exceptions.InvalidCategoryException;
import com.mindtree.bookstoreapp.manager.BookStoreManager;

public class BookStoreManagerImpl implements BookStoreManager
{
	private BookDAO bookDAO=new BookDAOImpl();
	public List<Book> getBookDetails(String category)
	{
		
		 try {
			return bookDAO.getBookDetails(category);
		} catch (InvalidCategoryException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			return null;
		}
		
	}
	public List<String> getCategory()
	{
		return bookDAO.getCategory();
		
	}
//	public int purchaseBook(int purchaseNo,Book bookId,String customerName,String customerMobileNo,Date purchaseDate,int amount)
//	{
//		return amount;
//		
//	}
	public int getAmount(int b)
	{
		return bookDAO.getAmount(b);
	}
	public List<Purchase> addPurchase(int bid,String custName,String custMobileNo,java.util.Date today,int amt)
	{
		return bookDAO.addPurchase(bid,custName,custMobileNo,today,amt);
	}
}
