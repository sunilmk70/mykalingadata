package com.mindtree.bookstoreapp.manager;

import java.util.Date;
import java.util.List;

import com.mindtree.bookstoreapp.entity.Book;
import com.mindtree.bookstoreapp.entity.Purchase;

public interface BookStoreManager 
{
	public List<Book> getBookDetails(String category);
	public List<String> getCategory();
	public int getAmount(int b);
	public List<Purchase> addPurchase(int bid,String custName,String custMobileNo,Date date,int amt);
	
}
