package com.mindtree.travelapp.exceptions;
public class InvalidDestinationName extends Throwable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidDestinationName(String s)
	{
		super(s);
	}
}
