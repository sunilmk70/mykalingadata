package com.mindtree.travelapp.utilities;

import java.sql.*;

public class DBUtil 
{
	//jdbc connection
	//Connection getConnection(),void closeConnection()
	private final static String uname="root";
	private final static String password="Welcome123";
	private final static String connec="jdbc:mysql://localhost:3306/td";
	private static Connection conn=null;
	
	public static Connection getConnection()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			conn=DriverManager.getConnection(connec,uname,password);
			//System.out.println(conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	public static void closeConnection()
	{
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
