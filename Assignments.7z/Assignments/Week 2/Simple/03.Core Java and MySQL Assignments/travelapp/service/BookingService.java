package com.mindtree.travelapp.service;
import com.mindtree.travelapp.entity.BookingDetails;

import com.mindtree.travelapp.entity.City;
//import com.mindtree.travelapp.exceptions.InvalidDestinationName;

//import com.mindtree.travelapp.utilities.*;
import java.util.*;
public interface BookingService 
{
	//interface getBookingDetails,use list
	public List<BookingDetails> getBookingDetails(City Destination);
	public boolean checkDestination(City destination);
}
