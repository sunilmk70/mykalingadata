package com.mindtree.travelapp.entity;

public class BookingDetails 
{
	
	private int id;
	private City source;
	private City destination;
	private Vehicle vehicleType;
	private long phoneno;
	public BookingDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookingDetails(int id, City source, City destination, Vehicle vehicleType, long phoneno) {
		super();
		this.id = id;
		this.source = source;
		this.destination = destination;
		this.vehicleType = vehicleType;
		this.phoneno = phoneno;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public City getSource() {
		return source;
	}
	public void setSource(City source) {
		this.source = source;
	}
	public City getDestination() {
		return destination;
	}
	public void setDestination(City destination) {
		this.destination = destination;
	}
	public Vehicle getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(Vehicle vehicleType) {
		this.vehicleType = vehicleType;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookingDetails other = (BookingDetails) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	
}
