package coreJavaBasic;
import java.util.*;
public class ConsecutiveCharacters 
{
	public static void main(String[] args) 
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter your String:");
		String str=scan.nextLine();
		str=str.toLowerCase();
		String res=""; 
		String st1="";
		char ar[]=str.toCharArray();
		for(int i = 0;i<ar.length;i++)
		{
		   if(ar[i]>='a'&&ar[i]<='z')
		   {
			   st1=st1+ar[i];
		   }
		}
	char ar1[]=st1.toCharArray();
	for (int i = 0; i < ar1.length; i++) 
	{
		for (int j = i; j < ar1.length-1;) 
		{	
				if((int)ar1[j]==(int)ar1[j+1]-1)
				{
					res=res+ar1[j];
					res=res+ar1[j+1];
					res=res+" ";
					break;
				}
				else
				{
					break;
				}
		
		}
	}
	String[] res1=res.split(" ");
	Map<String,Integer>m1=new HashMap<String,Integer>();
	for(int i=0;i<res1.length;i++)
	{
		if(m1.containsKey(res1[i]))
		{
			m1.put(res1[i],m1.get(res1[i])+1);
		}
		else
		{
			m1.put(res1[i],1);
		}
	}
	System.out.println(m1);
	scan.close();
	}
	
}