package coreJavaBasic;

import java.util.Scanner;

public class PersonSolution 
{

	public static void main(String[] args) 
	{
		Scanner scan=new Scanner(System.in);
		Person[] p=new Person[5];
		for(int i=0;i<5;i++)
		{
			System.out.println("Which details you want to enter?(Student/Professor):");
			String s=scan.next();
			if(s.equals("Student"))
			{
				System.out.println("Enter Student Name :");
				String sname=scan.next();
				System.out.println("Enter Student Percentage :");
				Double per=scan.nextDouble();
				p[i]=new Student(sname,per);
			}
			else if(s.equals("Professor"))
			{
				System.out.println("Enter Professor Name :");
				String pname=scan.next();
				System.out.println("Enter number of books published: ");
				int books=scan.nextInt();
				p[i]=new Professor(pname,books);
			}
			else
			{
				System.out.println("Please enter either Professor/Student");
				i=i-1;
			}
		}
		System.out.println("Whose details you want to print?(Student/Professor)");
		String sp=scan.next();
		if(sp.equals("Student"))
		{
			for(int i=0;i<5;i++)
			{
				if(p[i] instanceof Student)
				{
					if(p[i].isOutstanding())
					{
						((Student)p[i]).display();
					}
				}
			}
		}
		if(sp.equals("Professor"))
		{
			for(int i=0;i<5;i++)
			{
				if(p[i] instanceof Professor)
				{
					if(p[i].isOutstanding())
					{
						((Professor)p[i]).print();
					}
				}
			}
		}
	
		scan.close();
	}
}
