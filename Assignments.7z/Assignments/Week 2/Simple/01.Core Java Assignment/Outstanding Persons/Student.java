package coreJavaBasic;

public class Student extends Person
{
	double percentage;
	public Student()
	{
		percentage=0;
	}
	public Student(String name,double percentage)
	{
		super(name);
		this.percentage=percentage;
	}
	public void display()
	{
		System.out.println("Student Details:");
		System.out.println("Name : " + name);
		System.out.println("Percentage : " + percentage);
	}
	public boolean isOutstanding()
	{
		if(percentage >= 85)
			return true;
		else
			return false;
	}
}
