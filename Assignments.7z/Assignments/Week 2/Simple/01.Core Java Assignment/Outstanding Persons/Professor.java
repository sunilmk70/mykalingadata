package coreJavaBasic;

public class Professor extends Person
{
	int booksPublished;
	public Professor()
	{
		booksPublished=0;
	}
	public Professor(String name,int booksPublished)
	{
		super(name);
		this.booksPublished=booksPublished;
	}
	public void print()
	{
		System.out.println("Professor Details:");
		System.out.println("Name : " + name);
		System.out.println("Books Published : " + booksPublished);
	}
	public boolean isOutstanding()
	{
		if(booksPublished>4)
			return true;
		else
			return false;
	}
}
