package coreJavaBasic;

public abstract class Person 
{
	String name;
	public Person()
	{
		name="Default Name";
	}
	public Person(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return this.name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public abstract boolean isOutstanding();
}
