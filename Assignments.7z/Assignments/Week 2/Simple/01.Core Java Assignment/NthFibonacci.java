package coreJavaBasic;

import java.util.Scanner;

public class NthFibonacci 
{
	static int fib(int n)
    {
        if(n==0)
            return 0;
        if(n==1)
            return 1;
        else if(n==2)
            return 1;
        else
            return fib(n-1)+fib(n-2);
    }
    public static void main(String []args)
    {
    	Scanner scan=new Scanner(System.in);
    	System.out.println("Which Fibonacci number you want:");
    	int n=scan.nextInt();
    	System.out.println(n+"th Fibonacci number is: "+fib(n));
    	scan.close();
    }
}
