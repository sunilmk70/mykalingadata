package coreJavaBasic;
import java.util.Scanner;
public class CounterTest1 
{
	static int count=0;
    static class Counter 
    {
        
    	synchronized void increment() 
        {
        	count = count+1;
    	   
        }
        int getCount()
        {
        	return count;
        }
    }
    static Counter counter;          
    static int numberOfIncrements;   
    static class IThread implements Runnable
    {
        public void run() 
        {
        	for (int i = 0; i < numberOfIncrements; i++) {
            	counter.increment();
            }
        }
    }
    
    public static void main(String[] args) 
    {
        	Scanner in = new Scanner(System.in);             
            System.out.print("How many threads do you want to run: ");
            int numberOfThreads = in.nextInt();
            System.out.println("How many times should each thread increment the counter? ");
            numberOfIncrements = in.nextInt();
            IThread[] threads = new IThread[numberOfThreads];
          counter = new Counter();
            for (int i = 0; i < numberOfThreads; i++)
                threads[i] = new IThread();
            for (int i = 0; i < numberOfThreads; i++)
            {
            	Thread t1=new Thread(threads[i]);
            	t1.start();    
            }
            System.out.println("The final value of the counter should be "+ (numberOfIncrements*numberOfThreads));
            System.out.println("Actual final value of counter is: " + counter.getCount()); 
            in.close();
    } 
}
